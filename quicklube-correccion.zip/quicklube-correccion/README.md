# Quicklube — simulador de elevadores

Simulador por eventos discretos para decidir cuántos elevadores/mecánicos habilitar cada hora del sábado, midiendo los autos que se van al ver la fila y la plata que se pierde. Funciona sin servidor: todo se guarda en este navegador (IndexedDB).

## Instalar y correr

```bash
npm install
npm run dev     # abre la app en modo desarrollo
npm test        # tests del motor (src/engine) con cobertura mínima del 80 %
```

El archivo `.npmrc` incluye `legacy-peer-deps=true`: sin él, algunas versiones de npm cortan `npm install` por un conflicto de dependencias entre paquetes de Vite/Vitest.

## Tests

`npm test` ejecuta `vitest run src/engine/ --coverage` y falla si la cobertura del motor baja del 80 % (líneas, funciones, ramas y sentencias).

Qué cubren: generador mulberry32 y sus tres flujos independientes, montículo binario, determinismo (misma semilla = mismo sábado; cambiar duraciones no altera las llegadas), abandono con K, balanceadora compartida con salteo frente a FIFO estricto, eventos simultáneos, cierre exclusivo, tasa 0, ventas perdidas, Erlang C, dotación por hora, validaciones e historial con «Estado al…».

`src/engine/__tests__/criterios.test.ts` verifica con los parámetros de ejemplo del sábado que la franja de 11 a 12 recomienda 5 elevadores con el aviso de que el taller tiene 4, y que una hora con tasa 0 recomienda 1 elevador.

Resultado actual: 49 tests pasan; cobertura del motor 94,1 % sentencias, 82,6 % ramas, 98,9 % funciones, 96,0 % líneas.

## Datos de ejemplo

- **El catálogo es provisional**: servicios, precios, mezcla, duraciones, tasas de llegada por hora, horarios, K, cantidad de elevadores y reglas están en `src/config/catalogo.ts` (marcado «DATOS PROVISIONALES — se reemplazan con los del briefing»).
- Los **26.000 servicios históricos** (fechas, patentes, precios) son inventados por `src/data/semilla.ts` con una semilla fija. Si el navegador no deja guardar datos, se generan 2.000 en memoria.
- Los casos de prueba A–D del briefing (`src/engine/__tests__/casosBriefing.test.ts`) están marcados como pendientes: sus datos de entrada no llegaron en el briefing y no se inventaron resultados.

## Reiniciar los datos de ejemplo

Entrá a **Panel** (pedile la clave al encargado) y tocá **Reiniciar datos de ejemplo**. Regenera los servicios históricos y vuelve el catálogo al de fábrica (queda registrado en el historial). También podés borrar el historial desde ahí.

## Cambiar la clave del Panel

Calculá el SHA-256 de `sal:clave` y reemplazá `CLAVE_PANEL_HASH` (y si querés `CLAVE_PANEL_SAL`) en `src/config/catalogo.ts`.

## Estructura

- `src/engine/` — motor en TypeScript puro (sin React ni DOM): RNG mulberry32, montículo, simulador, Erlang C, validaciones, historial por eventos.
- `src/worker/sim.worker.ts` — corre las réplicas en segundo plano.
- `src/lib/store.ts` — estado, IndexedDB, deshacer/rehacer y sincronización entre pestañas (BroadcastChannel).
- `src/routes/` — pantallas: Tablero, Simular, Gantt, Dotación, Catálogo, Historial, Servicios, Panel.
