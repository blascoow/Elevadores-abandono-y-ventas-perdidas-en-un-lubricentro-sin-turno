import { describe, expect, it } from "vitest";
import { dotacionPorHora } from "../erlang";
import { ELEVADORES_TALLER, HORARIOS, REGLA_DOTACION, SERVICIOS } from "../../config/catalogo";

// Criterios de aceptación verificables con los parámetros de ejemplo del sábado.
describe("Criterio: dotación del sábado con parámetros de ejemplo", () => {
  const filas = dotacionPorHora(HORARIOS.sabado, SERVICIOS, REGLA_DOTACION, ELEVADORES_TALLER);
  const f11 = filas.find((f) => f.hora === 11)!;

  it("la franja de 11 a 12 recomienda 5 elevadores", () => {
    expect(f11.recomendado).toBe(5);
  });
  it("marca el aviso de que el taller tiene 4 elevadores", () => {
    expect(ELEVADORES_TALLER).toBe(4);
    expect(f11.superaTaller).toBe(true);
  });
  it("el resto de franjas del sábado entra en los 4 elevadores", () => {
    expect(filas.filter((f) => f.hora !== 11).every((f) => !f.superaTaller)).toBe(true);
  });
});

describe("Criterio: tasa 0 recomienda 1 elevador", () => {
  it("en la tabla por hora del día de semana", () => {
    const filas = dotacionPorHora(HORARIOS.semana, SERVICIOS, REGLA_DOTACION, ELEVADORES_TALLER);
    const sinAutos = filas.filter((f) => f.lambda === 0);
    expect(sinAutos.length).toBeGreaterThan(0);
    expect(sinAutos.every((f) => f.recomendado === 1)).toBe(true);
  });
});
