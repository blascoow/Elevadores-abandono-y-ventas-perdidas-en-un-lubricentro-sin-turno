import type { HorarioDia, Servicio } from "./types";

/** Probabilidad de esperar (Erlang C) con c servidores y carga a = λ/μ. */
export function erlangC(c: number, a: number): number {
  if (a <= 0) return 0;
  if (c <= a) return 1;
  let termino = 1;
  let suma = 1;
  for (let k = 1; k < c; k++) {
    termino *= a / k;
    suma += termino;
  }
  const ultimo = ((termino * a) / c) * (c / (c - a));
  return ultimo / (suma + ultimo);
}

/** Espera media en cola (misma unidad que 1/μ). */
export function esperaMediaErlang(c: number, lambda: number, mu: number): number {
  const a = lambda / mu;
  if (c <= a) return Infinity;
  return erlangC(c, a) / (c * mu - lambda);
}

/** P(espera > T). λ y μ por hora, T en minutos. */
export function probEsperaMayor(c: number, lambda: number, mu: number, Tmin: number): number {
  const a = lambda / mu;
  if (lambda <= 0) return 0;
  if (c <= a) return 1;
  return erlangC(c, a) * Math.exp(-(c * mu - lambda) * (Tmin / 60));
}

export function mediaPonderada(servicios: Servicio[]): number {
  const total = servicios.reduce((s, x) => s + x.mezcla, 0);
  if (total <= 0) return 0;
  return servicios.reduce((s, x) => s + x.media * x.mezcla, 0) / total;
}

export interface ReglaDotacion {
  esperaObjetivoMin: number;
  probMaxima: number;
}

export function recomendarElevadores(lambda: number, mediaMin: number, regla: ReglaDotacion): number {
  if (!(lambda > 0) || !(mediaMin > 0)) return 1;
  const mu = 60 / mediaMin;
  for (let c = 1; c <= 200; c++) {
    if (probEsperaMayor(c, lambda, mu, regla.esperaObjetivoMin) <= regla.probMaxima) return c;
  }
  return 200;
}

export interface FilaDotacion {
  hora: number;
  lambda: number;
  carga: number;
  recomendado: number;
  superaTaller: boolean;
  probEspera: number;
}

export function dotacionPorHora(horario: HorarioDia, servicios: Servicio[], regla: ReglaDotacion, elevadoresTaller: number): FilaDotacion[] {
  const media = mediaPonderada(servicios);
  const mu = media > 0 ? 60 / media : 0;
  return horario.tasas.map((lambda, i) => {
    // Tasa 0: hora sin llegadas, el briefing pide recomendar 1 elevador.
    const rec = recomendarElevadores(lambda, media, regla);
    return {
      hora: horario.apertura + i,
      lambda,
      carga: mu > 0 ? lambda / mu : 0,
      recomendado: rec,
      superaTaller: rec > elevadoresTaller,
      probEspera: lambda > 0 && mu > 0 ? erlangC(rec, lambda / mu) : 0,
    };
  });
}
