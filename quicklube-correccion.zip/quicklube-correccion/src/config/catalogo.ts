// =====================================================================
// DATOS PROVISIONALES — se reemplazan con los del briefing
// Único archivo con catálogo, tasas, horarios, K, elevadores y reglas.
// =====================================================================

export type DiaTipo = "sabado" | "semana";

export interface Servicio {
  id: string;
  nombre: string;
  /** Abreviatura para el Gantt cuando la barra es angosta */
  abreviatura: string;
  /** Precio en pesos argentinos */
  precio: number;
  /** Porcentaje de la mezcla (la suma tiene que dar 100) */
  mezcla: number;
  /** Duración media en minutos (modo Erlang) */
  media: number;
  /** Triangular (modo realista), en minutos */
  min: number;
  moda: number;
  max: number;
  usaBalanceadora: boolean;
}

export const SERVICIOS: Servicio[] = [
  { id: "aceite_filtros", nombre: "Cambio de aceite con filtros", abreviatura: "AF", precio: 68000, mezcla: 30, media: 36, min: 25, moda: 32, max: 50, usaBalanceadora: false },
  { id: "aceite_simple", nombre: "Cambio de aceite simple", abreviatura: "AS", precio: 45000, mezcla: 22, media: 23, min: 15, moda: 20, max: 35, usaBalanceadora: false },
  { id: "rotacion_balanceo", nombre: "Rotación y balanceo", abreviatura: "RB", precio: 38000, mezcla: 15, media: 41, min: 30, moda: 38, max: 55, usaBalanceadora: true },
  { id: "alineacion", nombre: "Alineación", abreviatura: "AL", precio: 32000, mezcla: 10, media: 31, min: 20, moda: 28, max: 45, usaBalanceadora: false },
  { id: "frenos", nombre: "Cambio de pastillas de freno", abreviatura: "FR", precio: 85000, mezcla: 8, media: 63, min: 45, moda: 55, max: 90, usaBalanceadora: false },
  { id: "revision", nombre: "Revisión general", abreviatura: "RG", precio: 25000, mezcla: 10, media: 26, min: 15, moda: 22, max: 40, usaBalanceadora: false },
  { id: "filtros_aire", nombre: "Filtro de aire y habitáculo", abreviatura: "FH", precio: 28000, mezcla: 5, media: 16, min: 10, moda: 14, max: 25, usaBalanceadora: false },
];

export interface HorarioDia {
  /** Hora de apertura (0-23) */
  apertura: number;
  /** Hora de cierre (exclusiva) */
  cierre: number;
  /** Autos por hora, una entrada por cada hora desde la apertura */
  tasas: number[];
}

export const HORARIOS: Record<DiaTipo, HorarioDia> = {
  // Sábado de 8 a 13, pico de 11 a 12 (con estos parámetros la franja de 11 a 12 recomienda 5 elevadores)
  sabado: { apertura: 8, cierre: 13, tasas: [3, 3.5, 4, 5, 3.5] },
  // Día de semana de 8 a 18; de 13 a 14 no se reciben autos (tasa 0)
  semana: { apertura: 8, cierre: 18, tasas: [2, 3, 3, 2.5, 2, 0, 2, 3, 3.5, 2.5] },
};

/** Elevadores habilitados por hora (por defecto) */
export const ELEVADORES_POR_HORA: Record<DiaTipo, number[]> = {
  sabado: [3, 4, 4, 4, 3],
  semana: [2, 2, 2, 2, 2, 1, 2, 2, 2, 2],
};

/** Cantidad física de elevadores del taller */
export const ELEVADORES_TALLER = 4;

/** Autos esperando a partir de los cuales un cliente se va */
export const K_ABANDONO = 4;

/**
 * Regla de dotación (Erlang C): mínima cantidad de elevadores tal que
 * P(espera > esperaObjetivoMin) <= probMaxima.
 * umbralPerdidosSim: perdidos promedio por hora tolerados en la recomendación por simulación.
 */
export const REGLA_DOTACION = {
  esperaObjetivoMin: 10,
  probMaxima: 0.2,
  umbralPerdidosSim: 0.5,
};

/** Regla de conflictos entre pestañas: gana el cambio con marca de tiempo más reciente */
export const REGLA_CONFLICTOS = "ultimo-gana" as const;
/** Ventana (ms) en la que dos cambios al mismo dato desde pestañas distintas se consideran conflicto */
export const VENTANA_CONFLICTO_MS = 3000;

/** Clave del Panel: solo se guarda el hash SHA-256 de `sal:clave` */
export const CLAVE_PANEL_SAL = "qlube-sal-7f3a9c";
export const CLAVE_PANEL_HASH = "368910395f6be22199e944d6289624b1e2ca70475f839831dfc5c8b5263508ad";

/** Datos de ejemplo */
export const SEMILLA_DATOS = 2026;
export const CANTIDAD_HISTORICOS = 26000;
export const CANTIDAD_HISTORICOS_SIN_IDB = 2000;

/** Simulación por defecto */
export const SIM_DEFECTO = {
  semilla: 12345,
  replicas: 30,
  modo: "realista" as const,
  politica: "salteo" as const,
};
