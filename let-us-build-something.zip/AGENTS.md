<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- `src/engine/` is pure TypeScript (no React/DOM) and covered by `npm test` with an 80 % coverage threshold; keep simulation logic there.
- All business data (catalog, rates, hours, K, rules, panel password) lives only in `src/config/catalogo.ts`.
- Simulations run in `src/worker/sim.worker.ts`; the UI never runs replicas on the main thread.
- Parameter changes are event-sourced (`src/engine/historial.ts`) and stored in IndexedDB via `src/lib/store.ts`; state is always rebuilt from factory + events.
