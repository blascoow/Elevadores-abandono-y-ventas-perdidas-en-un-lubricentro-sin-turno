const fmtPesos = new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 });
export const pesos = (n: number) => fmtPesos.format(Math.round(n));
export const num = (n: number, dec = 1) => n.toLocaleString("es-AR", { minimumFractionDigits: dec, maximumFractionDigits: dec });
export const pct = (x: number) => `${num(x * 100, 0)} %`;
export const franja = (h: number) => `${h} a ${h + 1} h`;
export const fechaHora = (ts: number) => new Date(ts).toLocaleString("es-AR", { dateStyle: "short", timeStyle: "medium" });
export const DIAS = { sabado: "Sábado", semana: "Día de semana" } as const;
