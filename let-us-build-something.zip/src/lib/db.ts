import type { Evento } from "@/engine/historial";
import type { RegistroHistorico } from "@/data/semilla";

const NOMBRE = "quicklube";
let dbPromise: Promise<IDBDatabase | null> | null = null;

export function abrirDB(): Promise<IDBDatabase | null> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    try {
      if (typeof indexedDB === "undefined") return resolve(null);
      const req = indexedDB.open(NOMBRE, 1);
      const timer = setTimeout(() => resolve(null), 4000);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("eventos")) db.createObjectStore("eventos", { keyPath: "id" });
        if (!db.objectStoreNames.contains("servicios")) db.createObjectStore("servicios", { keyPath: "id" });
      };
      req.onsuccess = () => {
        clearTimeout(timer);
        resolve(req.result);
      };
      req.onerror = () => {
        clearTimeout(timer);
        resolve(null);
      };
      req.onblocked = () => {
        clearTimeout(timer);
        resolve(null);
      };
    } catch {
      resolve(null);
    }
  });
  return dbPromise;
}

function tx<T>(db: IDBDatabase, store: string, modo: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T> | void): Promise<T | undefined> {
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, modo);
    const s = t.objectStore(store);
    const req = fn(s);
    t.oncomplete = () => resolve(req ? (req.result as T) : undefined);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
}

export const leerEventos = (db: IDBDatabase) => tx<Evento[]>(db, "eventos", "readonly", (s) => s.getAll()).then((x) => x ?? []);
export const guardarEvento = (db: IDBDatabase, e: Evento) => tx(db, "eventos", "readwrite", (s) => s.put(e));
export const borrarEventos = (db: IDBDatabase) => tx(db, "eventos", "readwrite", (s) => s.clear());
export const contarServicios = (db: IDBDatabase) => tx<number>(db, "servicios", "readonly", (s) => s.count()).then((x) => x ?? 0);
export const leerServicios = (db: IDBDatabase) => tx<RegistroHistorico[]>(db, "servicios", "readonly", (s) => s.getAll()).then((x) => x ?? []);
export function reemplazarServicios(db: IDBDatabase, regs: RegistroHistorico[]) {
  return tx(db, "servicios", "readwrite", (s) => {
    s.clear();
    for (const r of regs) s.put(r);
  });
}
