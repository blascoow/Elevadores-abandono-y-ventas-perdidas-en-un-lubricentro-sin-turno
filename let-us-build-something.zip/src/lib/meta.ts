export function meta(titulo: string, descripcion: string) {
  const title = `${titulo} — Quicklube`;
  return {
    meta: [
      { title },
      { name: "description", content: descripcion },
      { property: "og:title", content: title },
      { property: "og:description", content: descripcion },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  };
}
