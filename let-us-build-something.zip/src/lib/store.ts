import { useSyncExternalStore } from "react";
import {
  CANTIDAD_HISTORICOS,
  CANTIDAD_HISTORICOS_SIN_IDB,
  ELEVADORES_POR_HORA,
  ELEVADORES_TALLER,
  HORARIOS,
  K_ABANDONO,
  SEMILLA_DATOS,
  SERVICIOS,
  SIM_DEFECTO,
  VENTANA_CONFLICTO_MS,
  type DiaTipo,
} from "@/config/catalogo";
import { toast } from "sonner";
import { calcularPilas, clonar, crearDeshacer, crearRehacer, detectarConflicto, idConflicto, leerRuta, mismoValor, ordenar, reconstruir, textoConflicto, type Evento, type Pilas } from "@/engine/historial";
import type { Parametros, PedidoLote, ResultadoLote } from "@/engine/lote";
import type { ModoDuracion, Politica } from "@/engine/types";
import { generarServiciosHistoricos, type RegistroHistorico } from "@/data/semilla";
import * as db from "./db";

export const FABRICA: Parametros = {
  servicios: clonar(SERVICIOS),
  horarios: clonar(HORARIOS),
  elevadores: clonar(ELEVADORES_POR_HORA),
  K: K_ABANDONO,
  elevadoresTaller: ELEVADORES_TALLER,
};

export interface OpcionesSim {
  semilla: number;
  replicas: number;
  modo: ModoDuracion;
  politica: Politica;
  dia: DiaTipo;
}

export interface Estado {
  listo: boolean;
  sinIDB: boolean;
  sinWorker: boolean;
  eventos: Evento[];
  parametros: Parametros;
  pilas: Pilas;
  historicos: RegistroHistorico[] | null;
  generandoHistoricos: boolean;
  opciones: OpcionesSim;
  sim: { corriendo: boolean; hechas: number; total: number; mensaje: string | null; resultado: ResultadoLote | null; opcionesUsadas: OpcionesSim | null; parametrosUsados: Parametros | null };
}

let estado: Estado = {
  listo: false,
  sinIDB: false,
  sinWorker: false,
  eventos: [],
  parametros: clonar(FABRICA),
  pilas: { deshacer: [], rehacer: [] },
  historicos: null,
  generandoHistoricos: false,
  opciones: { ...SIM_DEFECTO, dia: "sabado" },
  sim: { corriendo: false, hechas: 0, total: 0, mensaje: null, resultado: null, opcionesUsadas: null, parametrosUsados: null },
};
const inicial = estado;
const oyentes = new Set<() => void>();

function set(parcial: Partial<Estado>) {
  estado = { ...estado, ...parcial };
  oyentes.forEach((f) => f());
}
function setSim(parcial: Partial<Estado["sim"]>) {
  set({ sim: { ...estado.sim, ...parcial } });
}

export function useStore<T>(sel: (e: Estado) => T): T {
  return useSyncExternalStore(
    (f) => {
      oyentes.add(f);
      return () => oyentes.delete(f);
    },
    () => sel(estado),
    () => sel(inicial),
  );
}
export const getEstado = () => estado;

// ---------------------------------------------------------------------
// Se genera recién al primer uso: el servidor publicado prohíbe azar al importar el módulo.
let origenCache: string | null = null;
function origen() {
  if (!origenCache) origenCache = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
  return origenCache;
}
let ultimoTs = 0;
function nuevoTs() {
  ultimoTs = Math.max(Date.now(), ultimoTs + 1);
  return ultimoTs;
}
const nuevoId = (ts: number) => `${ts.toString(36)}-${origen()}-${Math.random().toString(36).slice(2, 6)}`;

let base: IDBDatabase | null = null;
let canal: BroadcastChannel | null = null;

function recalcular(eventos: Evento[]) {
  const ord = ordenar(eventos);
  set({ eventos: ord, parametros: reconstruir(FABRICA, ord), pilas: calcularPilas(ord) });
}

async function persistir(e: Evento) {
  if (base) {
    try {
      await db.guardarEvento(base, e);
    } catch {
      /* sigue en memoria */
    }
  }
}

async function agregarLocal(e: Evento, difundir = true) {
  recalcular([...estado.eventos, e]);
  await persistir(e);
  if (difundir) canal?.postMessage({ tipo: "evento", evento: e });
}

function recibirRemoto(e: Evento) {
  if (estado.eventos.some((x) => x.id === e.id)) return;
  const conflicto = detectarConflicto(e, estado.eventos, origen(), VENTANA_CONFLICTO_MS);
  recalcular([...estado.eventos, e]);
  if (e.tipo === "conflicto") {
    toast.warning(e.descripcion);
    return;
  }
  if (conflicto) {
    const id = idConflicto(conflicto.ganador, conflicto.perdedor);
    if (estado.eventos.some((x) => x.id === id)) return;
    const ts = nuevoTs();
    const c: Evento = {
      id,
      ts,
      tipo: "conflicto",
      ruta: e.ruta,
      valor: clonar(conflicto.ganador.valor),
      anterior: clonar(conflicto.perdedor.valor),
      origen: origen(),
      refId: conflicto.perdedor.id,
      descripcion: textoConflicto(estado.parametros, conflicto.ganador, conflicto.perdedor),
    };
    toast.warning(c.descripcion);
    void agregarLocal(c);
  }
}

let iniciando: Promise<void> | null = null;
export function iniciar() {
  iniciando ??= iniciarUnaVez();
  return iniciando;
}
async function iniciarUnaVez() {
  if (estado.listo) return;
  base = await db.abrirDB();
  let eventos: Evento[] = [];
  if (base) {
    try {
      eventos = await db.leerEventos(base);
    } catch {
      base = null;
    }
  }
  set({ sinIDB: !base, listo: true });
  recalcular(eventos);
  if (typeof BroadcastChannel !== "undefined") {
    canal = new BroadcastChannel("quicklube");
    canal.onmessage = (m) => {
      const d = m.data;
      if (d?.tipo === "evento") recibirRemoto(d.evento as Evento);
      if (d?.tipo === "historial-borrado") recalcular([]);
      if (d?.tipo === "historicos") void cargarHistoricos(true);
    };
  }
  void simular();
  // Después de pintar la app, para no bloquear el arranque
  setTimeout(() => {
    cargarHistoricos().catch(() => set({ generandoHistoricos: false }));
  }, 100);
}

// ---------------------------------------------------------------------
export function cambiar(ruta: string, valor: unknown, descripcion: string) {
  const anterior = leerRuta(estado.parametros, ruta);
  if (mismoValor(anterior, valor)) return;
  const ts = nuevoTs();
  void agregarLocal({ id: nuevoId(ts), ts, tipo: "cambio", ruta, valor: clonar(valor), anterior: clonar(anterior), origen: origen(), descripcion });
}

export function deshacer() {
  const top = estado.pilas.deshacer.at(-1);
  if (!top) return;
  const ts = nuevoTs();
  void agregarLocal(crearDeshacer(top, nuevoId(ts), ts, origen()));
}
export function rehacer() {
  const top = estado.pilas.rehacer.at(-1);
  if (!top) return;
  const ts = nuevoTs();
  void agregarLocal(crearRehacer(top, nuevoId(ts), ts, origen()));
}

export async function borrarHistorial() {
  if (base) await db.borrarEventos(base);
  recalcular([]);
  canal?.postMessage({ tipo: "historial-borrado" });
}

// ---------------------------------------------------------------------
export async function cargarHistoricos(forzarLectura = false) {
  if (!forzarLectura && estado.generandoHistoricos) return;
  if (base) {
    try {
      const n = await db.contarServicios(base);
      if (n > 0) {
        set({ historicos: await db.leerServicios(base) });
        return;
      }
    } catch {
      /* se regeneran en memoria */
    }
  }
  await reiniciarHistoricos(false);
}

export async function reiniciarHistoricos(conReinicioCatalogo = true) {
  set({ generandoHistoricos: true });
  await new Promise((r) => setTimeout(r, 30));
  const regs = generarServiciosHistoricos(base ? CANTIDAD_HISTORICOS : CANTIDAD_HISTORICOS_SIN_IDB, SEMILLA_DATOS);
  if (base) {
    try {
      await db.reemplazarServicios(base, regs);
    } catch {
      /* queda en memoria */
    }
  }
  set({ historicos: regs, generandoHistoricos: false });
  if (conReinicioCatalogo) {
    const ts = nuevoTs();
    await agregarLocal({ id: nuevoId(ts), ts, tipo: "reinicio", ruta: "*", valor: null, anterior: null, origen: origen(), descripcion: "Reinicio de datos de ejemplo (catálogo de fábrica)" });
    canal?.postMessage({ tipo: "historicos" });
  }
}

// ---------------------------------------------------------------------
export function setOpciones(o: Partial<OpcionesSim>) {
  set({ opciones: { ...estado.opciones, ...o } });
}

export interface Corrida {
  promesa: Promise<ResultadoLote | null>;
  cancelar: () => void;
}

/** Respaldo si el navegador no deja crear el worker: corre en el hilo principal. */
function correrEnHilo(pedido: PedidoLote, progreso?: (h: number, t: number) => void): Corrida {
  let cancelado = false;
  const promesa = new Promise<ResultadoLote | null>((res) => {
    setTimeout(async () => {
      const { ejecutarLote } = await import("@/engine/lote");
      if (cancelado) return res(null);
      res(ejecutarLote(pedido, progreso));
    }, 50);
  });
  return { promesa, cancelar: () => (cancelado = true) };
}

export function correrEnWorker(pedido: PedidoLote, progreso?: (h: number, t: number) => void): Corrida {
  let w: Worker;
  try {
    if (typeof Worker === "undefined") throw new Error("sin Worker");
    w = new Worker(new URL("../worker/sim.worker.ts", import.meta.url), { type: "module" });
  } catch {
    set({ sinWorker: true });
    return correrEnHilo(pedido, progreso);
  }
  let resolver: (r: ResultadoLote | null) => void = () => {};
  const promesa = new Promise<ResultadoLote | null>((res) => (resolver = res));
  w.onmessage = (m) => {
    if (m.data.tipo === "progreso") progreso?.(m.data.hechas, m.data.total);
    else if (m.data.tipo === "fin") {
      resolver(m.data.res);
      w.terminate();
    }
  };
  w.onerror = () => {
    resolver(null);
    w.terminate();
  };
  w.postMessage(pedido);
  return {
    promesa,
    cancelar: () => {
      w.terminate();
      resolver(null);
    },
  };
}

let corridaActual: Corrida | null = null;

export async function simular() {
  if (estado.sim.corriendo) return;
  const o = estado.opciones;
  const parametros = clonar(estado.parametros);
  setSim({ corriendo: true, hechas: 0, total: 1, mensaje: null });
  corridaActual = correrEnWorker({ parametros, semilla: o.semilla, replicas: o.replicas, modo: o.modo, politica: o.politica, dias: ["sabado", "semana"], comparar: true }, (hechas, total) => setSim({ hechas, total }));
  const res = await corridaActual.promesa;
  corridaActual = null;
  if (res) setSim({ corriendo: false, resultado: res, opcionesUsadas: { ...o }, parametrosUsados: parametros, mensaje: null });
  else setSim({ corriendo: false, mensaje: "Simulación cancelada" });
}

export function cancelarSimulacion() {
  if (corridaActual) corridaActual.cancelar();
}
