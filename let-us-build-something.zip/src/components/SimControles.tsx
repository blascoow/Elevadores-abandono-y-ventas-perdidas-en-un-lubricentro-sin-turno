import { Play, Square } from "lucide-react";
import { Boton } from "./Boton";
import { cancelarSimulacion, simular, useStore } from "@/lib/store";

export function SimControles({ deshabilitado }: { deshabilitado?: boolean }) {
  const sim = useStore((e) => e.sim);
  const pct = sim.total > 0 ? Math.round((sim.hechas / sim.total) * 100) : 0;
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        {sim.corriendo ? (
          <Boton variante="secundario" onClick={cancelarSimulacion}>
            <Square className="size-4" /> Cancelar
          </Boton>
        ) : (
          <Boton onClick={() => void simular()} disabled={deshabilitado}>
            <Play className="size-4" /> Simular
          </Boton>
        )}
      </div>
      {sim.corriendo && (
        <div>
          <div className="h-3 overflow-hidden rounded-sm bg-secondary" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
            <div className="h-full bg-primary transition-[width]" style={{ width: `${pct}%` }} />
          </div>
          <div className="tablero mt-1 text-sm text-muted-foreground">
            {sim.hechas} / {sim.total} réplicas · {pct} %
          </div>
        </div>
      )}
      {sim.mensaje && <div className="text-sm font-semibold text-primary">{sim.mensaje}</div>}
      {sim.resultado && !sim.corriendo && <div className="tablero text-xs text-muted-foreground">Última corrida: {sim.resultado.duracionMs} ms</div>}
    </div>
  );
}
