import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const boton = cva("inline-flex min-h-10 items-center justify-center gap-2 rounded-md px-4 font-display text-base font-semibold uppercase tracking-wide transition-colors disabled:pointer-events-none disabled:opacity-40", {
  variants: {
    variante: {
      accion: "bg-primary text-primary-foreground hover:bg-primary/85",
      secundario: "border bg-secondary text-secondary-foreground hover:bg-accent",
      peligro: "border border-alerta text-alerta hover:bg-alerta hover:text-alerta-foreground",
      fantasma: "text-muted-foreground hover:bg-secondary hover:text-foreground",
    },
    tam: { normal: "", chico: "min-h-8 px-2.5 text-sm" },
  },
  defaultVariants: { variante: "accion", tam: "normal" },
});

export function Boton({ className, variante, tam, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof boton>) {
  return <button className={cn(boton({ variante, tam }), className)} {...p} />;
}
