import { Link, useRouterState } from "@tanstack/react-router";
import { BarChart3, BookOpen, CarFront, Database, GanttChart, History, Lock, Menu, Play, Users, Wrench, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { iniciar, useStore } from "@/lib/store";

const ITEMS = [
  { to: "/", label: "Tablero", icon: BarChart3 },
  { to: "/simular", label: "Simular", icon: Play },
  { to: "/gantt", label: "Gantt", icon: GanttChart },
  { to: "/dotacion", label: "Dotación", icon: Users },
  { to: "/catalogo", label: "Catálogo", icon: BookOpen },
  { to: "/historial", label: "Historial", icon: History },
  { to: "/servicios", label: "Servicios", icon: Database },
  { to: "/panel", label: "Panel", icon: Lock },
] as const;
const ABAJO = ITEMS.slice(0, 4);

export function AppShell({ children }: { children: ReactNode }) {
  const sinIDB = useStore((e) => e.sinIDB);
  const sinWorker = useStore((e) => e.sinWorker);
  const cargandoDatos = useStore((e) => e.listo && e.historicos === null);
  const [mas, setMas] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  useEffect(() => {
    void iniciar();
  }, []);
  useEffect(() => setMas(false), [path]);

  return (
    <div className="min-h-screen md:flex">
      <aside className="sticky top-0 hidden h-screen w-56 shrink-0 flex-col border-r bg-sidebar md:flex">
        <Marca />
        <nav className="flex flex-1 flex-col gap-1 p-3">
          {ITEMS.map((it) => (
            <Link key={it.to} to={it.to} activeOptions={{ exact: true }} className="flex items-center gap-3 rounded-md px-3 py-2 font-display text-lg uppercase tracking-wide text-muted-foreground hover:bg-sidebar-accent hover:text-foreground" activeProps={{ className: "bg-sidebar-accent text-primary" }}>
              <it.icon className="size-5" /> {it.label}
            </Link>
          ))}
        </nav>
        <div className="raya-taller h-2" />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {sinIDB && (
          <div role="alert" className="sticky top-0 z-40 bg-primary px-4 py-2 text-center font-display text-base font-semibold uppercase tracking-wide text-primary-foreground">
            Este navegador no deja guardar datos
          </div>
        )}
        {sinWorker && (
          <div role="status" className="bg-muted px-4 py-1.5 text-center text-sm text-foreground">
            Las simulaciones corren más lento en este navegador (sin proceso en segundo plano).
          </div>
        )}
        {cargandoDatos && (
          <div role="status" className="bg-muted px-4 py-1.5 text-center text-sm text-muted-foreground">
            Cargando servicios de ejemplo…
          </div>
        )}
        <header className="flex items-center justify-between border-b bg-sidebar px-4 py-2 md:hidden">
          <Marca compacta />
        </header>
        <main className="mx-auto w-full max-w-6xl flex-1 px-3 pb-28 pt-4 sm:px-5 md:pb-10">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t bg-sidebar md:hidden">
        {ABAJO.map((it) => (
          <Link key={it.to} to={it.to} activeOptions={{ exact: true }} className="flex flex-col items-center gap-0.5 py-2 font-display text-xs uppercase tracking-wide text-muted-foreground" activeProps={{ className: "text-primary" }}>
            <it.icon className="size-5" />
            {it.label}
          </Link>
        ))}
        <button onClick={() => setMas(true)} className="flex flex-col items-center gap-0.5 py-2 font-display text-xs uppercase tracking-wide text-muted-foreground" aria-label="Más secciones">
          <Menu className="size-5" /> Más
        </button>
      </nav>

      {mas && (
        <div className="fixed inset-0 z-50 flex items-end bg-background/80 md:hidden" onClick={() => setMas(false)}>
          <div className="w-full rounded-t-lg border-t bg-sidebar p-3 pb-6" onClick={(e) => e.stopPropagation()}>
            <div className="mb-2 flex items-center justify-between">
              <span className="etiqueta">Secciones</span>
              <button onClick={() => setMas(false)} aria-label="Cerrar" className="p-2">
                <X className="size-5" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {ITEMS.slice(4).map((it) => (
                <Link key={it.to} to={it.to} className="flex items-center gap-2 rounded-md border bg-card px-3 py-3 font-display text-lg uppercase" activeProps={{ className: "border-primary text-primary" }}>
                  <it.icon className="size-5" /> {it.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Marca({ compacta }: { compacta?: boolean }) {
  return (
    <div className={`flex items-center gap-2 ${compacta ? "" : "border-b px-4 py-4"}`}>
      <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
        <Wrench className="size-5" />
      </div>
      <div className="leading-none">
        <div className="font-display text-2xl font-bold uppercase tracking-wide">Quicklube</div>
        <div className="etiqueta flex items-center gap-1">
          <CarFront className="size-3" /> Simulador de sábado
        </div>
      </div>
    </div>
  );
}

export function Titulo({ children, sub }: { children: ReactNode; sub?: ReactNode }) {
  return (
    <div className="mb-4">
      <h1 className="text-3xl font-bold uppercase sm:text-4xl">{children}</h1>
      {sub && <p className="mt-1 text-sm text-muted-foreground">{sub}</p>}
    </div>
  );
}

export function Dato({ etiqueta, valor, extra, tono = "normal" }: { etiqueta: string; valor: ReactNode; extra?: ReactNode; tono?: "normal" | "alerta" | "info" }) {
  const color = tono === "alerta" ? "text-alerta" : tono === "info" ? "text-info" : "text-foreground";
  return (
    <div className="panel p-3">
      <div className="etiqueta">{etiqueta}</div>
      <div className={`tablero text-2xl font-semibold sm:text-3xl ${color}`}>{valor}</div>
      {extra && <div className="tablero text-xs text-muted-foreground">{extra}</div>}
    </div>
  );
}
