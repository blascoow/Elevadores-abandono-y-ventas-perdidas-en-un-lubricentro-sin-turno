import { createFileRoute } from "@tanstack/react-router";
import { Save, Scale } from "lucide-react";
import { useEffect, useState } from "react";
import { Titulo } from "@/components/AppShell";
import { Boton } from "@/components/Boton";
import type { DiaTipo, Servicio } from "@/config/catalogo";
import { MSG_PRECIO, parsearPrecio, validarMezcla, validarTriangular } from "@/engine/validar";
import { DIAS, franja, pesos } from "@/lib/formato";
import { meta } from "@/lib/meta";
import { cambiar, useStore } from "@/lib/store";

export const Route = createFileRoute("/catalogo")({
  head: () => meta("Catálogo", "Precios, mezcla de servicios, duraciones y llegadas por hora del lubricentro."),
  component: Catalogo,
});

function Catalogo() {
  const p = useStore((e) => e.parametros);
  return (
    <>
      <Titulo sub="Precios y duraciones de referencia. Cada cambio queda en el historial.">Catálogo</Titulo>
      <div className="space-y-4">
        <div className="grid gap-3 md:grid-cols-2">
          {p.servicios.map((s) => (
            <TarjetaServicio key={s.id} s={s} />
          ))}
        </div>
        <Mezcla servicios={p.servicios} />
        <div className="grid gap-3 md:grid-cols-2">
          {(["sabado", "semana"] as DiaTipo[]).map((d) => (
            <Tasas key={d} dia={d} />
          ))}
        </div>
      </div>
    </>
  );
}

function TarjetaServicio({ s }: { s: Servicio }) {
  const [precio, setPrecio] = useState(String(s.precio));
  const [errPrecio, setErrPrecio] = useState<string | null>(null);
  const [dur, setDur] = useState({ media: String(s.media), min: String(s.min), moda: String(s.moda), max: String(s.max) });
  const [errDur, setErrDur] = useState<string | null>(null);
  useEffect(() => setPrecio(String(s.precio)), [s.precio]);
  useEffect(() => setDur({ media: String(s.media), min: String(s.min), moda: String(s.moda), max: String(s.max) }), [s.media, s.min, s.moda, s.max]);

  const guardarPrecio = () => {
    const v = parsearPrecio(precio);
    if (v === null) {
      setErrPrecio(MSG_PRECIO);
      setPrecio(String(s.precio));
      return;
    }
    setErrPrecio(null);
    cambiar(`servicio.${s.id}.precio`, v, `Precio de ${s.nombre}: ${pesos(v)}`);
  };
  const guardarDur = () => {
    const n = { media: Number(dur.media), min: Number(dur.min), moda: Number(dur.moda), max: Number(dur.max) };
    const e = validarTriangular(n.min, n.moda, n.max) ?? (n.media > 0 ? null : "La duración media tiene que ser mayor que 0");
    setErrDur(e);
    if (e) return;
    cambiar(`servicio.${s.id}.duracion`, n, `Duración de ${s.nombre}: media ${n.media}′ (${n.min}/${n.moda}/${n.max})`);
  };

  return (
    <div className="panel p-3">
      <div className="mb-2 flex items-start justify-between gap-2">
        <h2 className="text-xl font-semibold uppercase leading-tight">{s.nombre}</h2>
        {s.usaBalanceadora && (
          <span className="inline-flex shrink-0 items-center gap-1 rounded-sm bg-primary/20 px-1.5 py-0.5 font-display text-xs uppercase text-primary">
            <Scale className="size-3" /> Balanceadora
          </span>
        )}
      </div>
      <label className="block">
        <span className="etiqueta">Precio (ARS)</span>
        <input className="campo tablero text-lg" inputMode="numeric" value={precio} onChange={(e) => setPrecio(e.target.value)} onBlur={guardarPrecio} onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()} aria-label={`Precio de ${s.nombre}`} />
      </label>
      {errPrecio && <p className="mt-1 text-sm font-semibold text-primary">{errPrecio}</p>}
      <div className="mt-2 grid grid-cols-4 gap-2">
        {(["media", "min", "moda", "max"] as const).map((k) => (
          <label key={k}>
            <span className="etiqueta">{k === "min" ? "Mín" : k === "max" ? "Máx" : k === "moda" ? "Moda" : "Media"}</span>
            <input className="campo" inputMode="decimal" value={dur[k]} onChange={(e) => setDur({ ...dur, [k]: e.target.value })} />
          </label>
        ))}
      </div>
      <div className="mt-2 flex items-center justify-between gap-2">
        <span className="text-xs text-muted-foreground">Minutos</span>
        <Boton tam="chico" variante="secundario" onClick={guardarDur}>
          <Save className="size-4" /> Guardar duración
        </Boton>
      </div>
      {errDur && <p className="mt-1 text-sm font-semibold text-primary">{errDur}</p>}
    </div>
  );
}

function Mezcla({ servicios }: { servicios: Servicio[] }) {
  const clave = servicios.map((s) => s.mezcla).join(",");
  const [m, setM] = useState<Record<string, string>>({});
  useEffect(() => setM(Object.fromEntries(servicios.map((s) => [s.id, String(s.mezcla)]))), [clave]); // eslint-disable-line react-hooks/exhaustive-deps
  const valores = servicios.map((s) => Number(m[s.id] ?? s.mezcla));
  const error = validarMezcla(valores);
  return (
    <div className="panel p-3">
      <h2 className="text-xl font-semibold uppercase">Mezcla de servicios</h2>
      <p className="mb-2 text-sm text-muted-foreground">Porcentaje de autos que piden cada servicio.</p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {servicios.map((s) => (
          <label key={s.id}>
            <span className="etiqueta line-clamp-1">{s.nombre}</span>
            <div className="flex items-center gap-1">
              <input className="campo" inputMode="decimal" value={m[s.id] ?? ""} onChange={(e) => setM({ ...m, [s.id]: e.target.value })} aria-label={`Mezcla de ${s.nombre}`} />
              <span>%</span>
            </div>
          </label>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <p className={`text-sm font-semibold ${error ? "text-primary" : "text-info"}`}>{error ?? "La mezcla suma 100 %"}</p>
        <Boton
          tam="chico"
          disabled={!!error}
          onClick={() => {
            const v = Object.fromEntries(servicios.map((s, i) => [s.id, valores[i]]));
            cambiar("mezcla", v, "Mezcla de servicios");
          }}
        >
          <Save className="size-4" /> Guardar mezcla
        </Boton>
      </div>
    </div>
  );
}

function Tasas({ dia }: { dia: DiaTipo }) {
  const h = useStore((e) => e.parametros.horarios[dia]);
  const [err, setErr] = useState<string | null>(null);
  return (
    <div className="panel p-3">
      <h2 className="text-xl font-semibold uppercase">Llegadas por hora · {DIAS[dia]}</h2>
      <p className="mb-2 text-sm text-muted-foreground">Autos por hora (0 = no se reciben autos).</p>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {h.tasas.map((t, i) => (
          <label key={`${i}-${t}`}>
            <span className="etiqueta">{franja(h.apertura + i)}</span>
            <input
              className="campo"
              inputMode="decimal"
              defaultValue={t}
              onBlur={(e) => {
                const v = Number(e.target.value.replace(",", "."));
                if (e.target.value.trim() === "" || !Number.isFinite(v) || v < 0) {
                  setErr("La tasa tiene que ser un número mayor o igual a 0");
                  e.target.value = String(t);
                  return;
                }
                setErr(null);
                const n = [...h.tasas];
                n[i] = v;
                cambiar(`tasas.${dia}`, n, `Llegadas ${DIAS[dia].toLowerCase()} ${franja(h.apertura + i)}: ${v}/h`);
              }}
            />
          </label>
        ))}
      </div>
      {err && <p className="mt-1 text-sm font-semibold text-primary">{err}</p>}
    </div>
  );
}
