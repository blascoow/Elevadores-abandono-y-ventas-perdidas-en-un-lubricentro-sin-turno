import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle } from "lucide-react";
import { useState } from "react";
import { Titulo } from "@/components/AppShell";
import { SimControles } from "@/components/SimControles";
import { REGLA_DOTACION, type DiaTipo } from "@/config/catalogo";
import { dotacionPorHora } from "@/engine/erlang";
import { recomendacionPorSimulacion } from "@/engine/lote";
import { franja, num, pct } from "@/lib/formato";
import { meta } from "@/lib/meta";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/dotacion")({
  head: () => meta("Dotación", "Elevadores recomendados por hora según Erlang C frente a la simulación con abandono y balanceadora."),
  component: Dotacion,
});

function Dotacion() {
  const p = useStore((e) => e.parametros);
  const sim = useStore((e) => e.sim);
  const [dia, setDia] = useState<DiaTipo>("sabado");
  const filas = dotacionPorHora(p.horarios[dia], p.servicios, REGLA_DOTACION, p.elevadoresTaller);
  const recSim = dia === "sabado" && sim.resultado ? recomendacionPorSimulacion(sim.resultado.comparacion, REGLA_DOTACION.umbralPerdidosSim) : [];
  const res = sim.resultado?.dias[dia];
  const supera = filas.some((f) => f.superaTaller);

  return (
    <>
      <Titulo sub={`Erlang C: mínimo de elevadores para que la probabilidad de esperar más de ${REGLA_DOTACION.esperaObjetivoMin} min no pase de ${pct(REGLA_DOTACION.probMaxima)}. No contempla abandono ni balanceadora.`}>Dotación por hora</Titulo>
      <div className="mb-3 flex flex-wrap items-end gap-3">
        <label className="w-44">
          <span className="etiqueta">Día</span>
          <select className="campo" value={dia} onChange={(e) => setDia(e.target.value as DiaTipo)}>
            <option value="sabado">Sábado</option>
            <option value="semana">Día de semana</option>
          </select>
        </label>
      </div>
      {supera && (
        <div role="alert" className="mb-3 flex items-center gap-2 rounded-md border-2 border-primary bg-primary/10 p-3 font-display text-lg font-semibold uppercase text-primary">
          <AlertTriangle className="size-5 shrink-0" /> El taller tiene {p.elevadoresTaller} {p.elevadoresTaller === 1 ? "elevador" : "elevadores"}
        </div>
      )}
      <div className="panel overflow-x-auto">
        <table className="tablero w-full min-w-[560px] text-right text-base">
          <thead className="etiqueta">
            <tr>
              <th className="sticky left-0 z-10 bg-card p-2 text-left">Franja</th>
              <th className="p-2">Autos/h</th>
              <th className="p-2">Carga</th>
              <th className="p-2">Erlang C</th>
              <th className="p-2">Simulación</th>
              <th className="p-2">Habilitados</th>
              <th className="p-2">Perdidos sim.</th>
            </tr>
          </thead>
          <tbody>
            {filas.map((f, i) => (
              <tr key={f.hora} className="border-t">
                <td className="sticky left-0 z-10 bg-card p-2 text-left">{franja(f.hora)}</td>
                <td className="p-2 text-info">{num(f.lambda)}</td>
                <td className="p-2">{num(f.carga, 2)}</td>
                <td className={`p-2 text-lg font-semibold ${f.superaTaller ? "text-primary" : ""}`}>
                  {f.recomendado}
                  {f.lambda > 0 && f.superaTaller && <AlertTriangle className="ml-1 inline size-4" aria-label="Supera el taller" />}
                </td>
                <td className="p-2 text-lg font-semibold">{dia === "sabado" ? (recSim[i] ?? (recSim.length ? `> ${p.elevadoresTaller}` : "—")) : "—"}</td>
                <td className="p-2">{p.elevadores[dia][i]}</td>
                <td className="p-2 text-alerta">{res ? num(res.perdidosPorHora[i]) : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        «Simulación»: menor cantidad de elevadores fijos con la que se pierden en promedio {num(REGLA_DOTACION.umbralPerdidosSim)} autos o menos en esa hora (solo sábado). «Perdidos sim.» usa los elevadores habilitados.
      </p>
      {!sim.resultado && <div className="mt-3"><SimControles /></div>}
    </>
  );
}
