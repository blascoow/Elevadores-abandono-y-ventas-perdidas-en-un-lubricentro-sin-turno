import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, Clock, Redo2, Undo2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Dato, Titulo } from "@/components/AppShell";
import { Boton } from "@/components/Boton";
import { reconstruir, type Evento } from "@/engine/historial";
import type { Parametros, ResultadoLote } from "@/engine/lote";
import { fechaHora, num, pesos } from "@/lib/formato";
import { meta } from "@/lib/meta";
import { correrEnWorker, deshacer, FABRICA, rehacer, useStore, type Corrida } from "@/lib/store";

export const Route = createFileRoute("/historial")({
  head: () => meta("Historial", "Todos los cambios con fecha y hora, deshacer y rehacer, y el estado del catálogo en cualquier momento."),
  component: Historial,
});

const ICONO: Record<Evento["tipo"], string> = { cambio: "Cambio", deshacer: "Deshacer", rehacer: "Rehacer", conflicto: "Conflicto", reinicio: "Reinicio" };

function aLocal(ts: number) {
  const d = new Date(ts - new Date(ts).getTimezoneOffset() * 60000);
  return d.toISOString().slice(0, 19);
}

function Historial() {
  const eventos = useStore((e) => e.eventos);
  const pilas = useStore((e) => e.pilas);
  const opciones = useStore((e) => e.opciones);
  const listo = useStore((e) => e.listo);
  const [momento, setMomento] = useState("");
  const [aviso, setAviso] = useState<string | null>(null);
  // Hora local recién en el navegador, cuando ya cargó el historial guardado
  useEffect(() => {
    if (listo) setMomento((m) => m || aLocal(Date.now()));
  }, [listo]);
  const [vista, setVista] = useState<{ p: Parametros; antes: boolean; ts: number } | null>(null);
  const [res, setRes] = useState<ResultadoLote | null>(null);
  const [calc, setCalc] = useState(false);
  const corrida = useRef<Corrida | null>(null);
  useEffect(() => () => corrida.current?.cancelar(), []);

  const ver = async () => {
    if (!momento) {
      setAviso("Elegí una fecha y hora");
      setVista(null);
      return;
    }
    const pedido = new Date(momento).getTime();
    if (!Number.isFinite(pedido)) {
      setAviso("Elegí una fecha y hora");
      return;
    }
    const futura = pedido > Date.now();
    setAviso(futura ? "Fecha futura: se muestra el estado actual" : null);
    const ts = futura ? Date.now() : pedido;
    const antes = eventos.length === 0 || ts < eventos[0].ts;
    const p = antes ? structuredClone(FABRICA) : reconstruir(FABRICA, eventos, ts);
    setVista({ p, antes, ts });
    setRes(null);
    corrida.current?.cancelar();
    setCalc(true);
    corrida.current = correrEnWorker({ parametros: p, semilla: opciones.semilla, replicas: 30, modo: opciones.modo, politica: opciones.politica, dias: ["sabado"], comparar: false });
    const r = await corrida.current.promesa;
    setCalc(false);
    if (r) setRes(r);
  };

  const lista = [...eventos].reverse();

  return (
    <>
      <Titulo sub="Cada cambio queda guardado con fecha y hora, incluso los deshacer y rehacer.">Historial</Titulo>
      <div className="grid gap-4 lg:grid-cols-[1fr_minmax(0,420px)]">
        <section className="space-y-3">
          <div className="panel flex flex-wrap gap-2 p-3">
            <Boton variante="secundario" onClick={deshacer} disabled={!pilas.deshacer.length}>
              <Undo2 className="size-4" /> Deshacer ({pilas.deshacer.length})
            </Boton>
            <Boton variante="secundario" onClick={rehacer} disabled={!pilas.rehacer.length}>
              <Redo2 className="size-4" /> Rehacer ({pilas.rehacer.length})
            </Boton>
          </div>
          <div className="panel divide-y">
            {!listo && <p className="p-4 text-muted-foreground">Cargando historial…</p>}
            {listo && lista.length === 0 && <p className="p-4 text-muted-foreground">Todavía no hay cambios. Editá algo en Catálogo o Simular.</p>}
            {listo && lista.slice(0, 400).map((e) => (
              <div key={e.id} className="flex items-start gap-3 p-3">
                <span className={`mt-0.5 shrink-0 rounded-sm px-1.5 py-0.5 font-display text-xs uppercase ${e.tipo === "conflicto" ? "bg-primary text-primary-foreground" : e.tipo === "cambio" ? "bg-info/25 text-info" : "bg-secondary"}`}>
                  {e.tipo === "conflicto" && <AlertTriangle className="mr-0.5 inline size-3" />}
                  {ICONO[e.tipo]}
                </span>
                <div className="min-w-0">
                  <div className="text-sm">{e.descripcion}</div>
                  <div className="tablero text-xs text-muted-foreground">{fechaHora(e.ts)} · pestaña {e.origen}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <div className="panel p-3">
            <h2 className="flex items-center gap-2 text-xl font-semibold uppercase"><Clock className="size-5" /> Estado al…</h2>
            <div className="mt-2 flex flex-wrap items-end gap-2">
              <input type="datetime-local" step={1} className="campo flex-1" value={momento} onChange={(e) => setMomento(e.target.value)} aria-label="Fecha y hora" />
              <Boton onClick={() => void ver()} disabled={!listo}>Ver</Boton>
            </div>
            {aviso && <p className="mt-2 rounded-sm border border-info p-2 text-sm text-info">{aviso}</p>}
          </div>
          {vista && (
            <div className="panel space-y-3 p-3">
              <div className="tablero text-sm text-muted-foreground">{fechaHora(vista.ts)}</div>
              {vista.antes && <p className="rounded-sm border border-info p-2 text-sm text-info">Es anterior al primer cambio: se muestra el catálogo de fábrica.</p>}
              <div className="grid grid-cols-2 gap-2">
                <Dato etiqueta="Ingreso perdido sábado" valor={calc ? "…" : res?.dias.sabado ? pesos(res.dias.sabado.ingresoPerdido.media) : "—"} tono="alerta" />
                <Dato etiqueta="Autos perdidos" valor={calc ? "…" : res?.dias.sabado ? num(res.dias.sabado.perdidos.media) : "—"} tono="alerta" />
              </div>
              <table className="tablero w-full text-right text-sm">
                <thead className="etiqueta"><tr><th className="text-left">Servicio</th><th>Precio</th><th>Mezcla</th><th>Media</th></tr></thead>
                <tbody>
                  {vista.p.servicios.map((s) => (
                    <tr key={s.id} className="border-t"><td className="py-1 text-left">{s.nombre}</td><td>{pesos(s.precio)}</td><td>{s.mezcla} %</td><td>{s.media}′</td></tr>
                  ))}
                </tbody>
              </table>
              <div className="tablero text-sm text-muted-foreground">K = {vista.p.K} · elevadores sábado {vista.p.elevadores.sabado.join("/")} · llegadas sábado {vista.p.horarios.sabado.tasas.join("/")}</div>
            </div>
          )}
        </section>
      </div>
    </>
  );
}
