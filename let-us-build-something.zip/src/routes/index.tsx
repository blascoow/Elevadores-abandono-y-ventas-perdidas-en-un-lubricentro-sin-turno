import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Dato, Titulo } from "@/components/AppShell";
import { SimControles } from "@/components/SimControles";
import { franja, num, pesos } from "@/lib/formato";
import { meta } from "@/lib/meta";
import { simular, useStore } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => meta("Tablero", "Ingreso perdido del sábado, autos que se van por la fila y cuánto recupera cada elevador extra."),
  component: Tablero,
});

function Tablero() {
  const listo = useStore((e) => e.listo);
  const sim = useStore((e) => e.sim);
  const params = sim.parametrosUsados;
  useEffect(() => {
    if (listo && !sim.resultado && !sim.corriendo && !sim.mensaje) void simular();
  }, [listo, sim.resultado, sim.corriendo, sim.mensaje]);

  const sab = sim.resultado?.dias.sabado;
  const sem = sim.resultado?.dias.semana;
  const apertura = params?.horarios.sabado.apertura ?? 8;
  const datos = sab?.perdidosPorHora.map((p, i) => ({ hora: `${apertura + i}h`, perdidos: Number(p.toFixed(2)), monto: sab.ingresoPerdidoPorHora[i] })) ?? [];
  const comp = sim.resultado?.comparacion ?? [];

  return (
    <>
      <Titulo sub="Promedio de las réplicas con la dotación actual. Atención por orden de llegada.">Tablero</Titulo>
      {!sab ? (
        <div className="panel p-6">
          <SimControles />
          {!sim.corriendo && !sim.mensaje && <p className="text-muted-foreground">Preparando simulación…</p>}
        </div>
      ) : (
        <div className="space-y-4">
          <section className="panel overflow-hidden">
            <div className="raya-taller h-1.5" />
            <div className="p-4 sm:p-6">
              <div className="etiqueta">Ingreso perdido por sábado</div>
              <div className="tablero text-5xl font-bold leading-none text-alerta sm:text-7xl">{pesos(sab.ingresoPerdido.media)}</div>
              <div className="tablero mt-1 text-sm text-muted-foreground">
                IC 95 %: ± {pesos(sab.ingresoPerdido.ic)} · {sim.opcionesUsadas?.replicas} réplicas
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Dato etiqueta="Autos perdidos" valor={num(sab.perdidos.media)} tono="alerta" extra={`± ${num(sab.perdidos.ic)}`} />
                <Dato etiqueta="Atendidos" valor={num(sab.atendidos.media)} tono="info" />
                <Dato etiqueta="Espera media" valor={`${num(sab.esperaMedia.media)} min`} tono="info" />
                <Dato etiqueta="Perdido al mes" valor={pesos(sab.ingresoPerdido.media * 4.3)} tono="alerta" extra="≈ 4,3 sábados" />
              </div>
            </div>
          </section>

          <section className="panel p-4">
            <h2 className="mb-2 text-xl font-semibold uppercase">Autos perdidos por hora · sábado</h2>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={datos} margin={{ left: -20, right: 4, top: 8 }}>
                  <CartesianGrid stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="hora" stroke="var(--muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} allowDecimals />
                  <Tooltip
                    cursor={{ fill: "var(--secondary)" }}
                    contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }}
                    formatter={(v: number, _n, item) => [`${num(v)} autos · ${pesos(item.payload.monto)}`, "Perdidos"]}
                  />
                  <Bar dataKey="perdidos" fill="var(--alerta)" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>

          <section className="panel p-4">
            <h2 className="text-xl font-semibold uppercase">¿Cuánto recupera cada elevador extra?</h2>
            <p className="mb-3 text-sm text-muted-foreground">Sábado con la misma cantidad de elevadores toda la mañana.</p>
            <div className="overflow-x-auto">
              <table className="tablero w-full min-w-[320px] text-right text-base">
                <thead className="etiqueta">
                  <tr>
                    <th className="py-1 text-left">Elevadores</th>
                    <th>Perdidos</th>
                    <th>Ingreso perdido</th>
                    <th>Recupera</th>
                  </tr>
                </thead>
                <tbody>
                  {comp.map((c, i) => {
                    const prev = comp[i - 1];
                    const autos = prev ? prev.resumen.perdidos.media - c.resumen.perdidos.media : 0;
                    const plata = prev ? prev.resumen.ingresoPerdido.media - c.resumen.ingresoPerdido.media : 0;
                    return (
                      <tr key={c.c} className="border-t">
                        <td className="py-2 text-left text-lg font-semibold">{c.c}</td>
                        <td className="text-alerta">{num(c.resumen.perdidos.media)}</td>
                        <td className="text-alerta">{pesos(c.resumen.ingresoPerdido.media)}</td>
                        <td className="text-info">{prev ? `+${num(autos)} · ${pesos(plata)}` : "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>

          {sem && params && (
            <section className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <Dato etiqueta="Día de semana · ingreso perdido" valor={pesos(sem.ingresoPerdido.media)} tono="alerta" />
              <Dato etiqueta="Día de semana · perdidos" valor={num(sem.perdidos.media)} tono="alerta" />
              <Dato etiqueta="Peor franja del sábado" valor={franja(apertura + sab.perdidosPorHora.indexOf(Math.max(...sab.perdidosPorHora)))} />
            </section>
          )}
          <SimControles />
        </div>
      )}
    </>
  );
}
