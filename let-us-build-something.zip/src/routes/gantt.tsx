import { createFileRoute } from "@tanstack/react-router";
import { ZoomIn, ZoomOut } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Titulo } from "@/components/AppShell";
import { Boton } from "@/components/Boton";
import { SimControles } from "@/components/SimControles";
import type { DiaTipo } from "@/config/catalogo";
import type { Perdido, Trabajo } from "@/engine/types";
import { DIAS, num, pesos } from "@/lib/formato";
import { meta } from "@/lib/meta";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/gantt")({
  head: () => meta("Gantt", "Línea de tiempo de una réplica: los 4 elevadores, la balanceadora y los autos perdidos."),
  component: Gantt,
});

const FILA = 44;
const COL = 92;
/** Margen izquierdo para que la etiqueta de apertura no quede cortada */
const PAD = 22;

function hhmm(apertura: number, t: number) {
  const m = Math.round(apertura * 60 + t);
  return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`;
}

function Gantt() {
  const sim = useStore((e) => e.sim);
  const [dia, setDia] = useState<DiaTipo>("sabado");
  const [rep, setRep] = useState(0);
  const [zoom, setZoom] = useState(3);
  const [sel, setSel] = useState<{ tipo: "t"; x: Trabajo } | { tipo: "p"; x: Perdido } | { tipo: "g"; x: Perdido[] } | null>(null);
  const caja = useRef<HTMLDivElement>(null);
  const [anchoCaja, setAnchoCaja] = useState(0);
  useEffect(() => {
    const el = caja.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => setAnchoCaja(el.clientWidth));
    ro.observe(el);
    setAnchoCaja(el.clientWidth);
    return () => ro.disconnect();
  });
  const p = sim.parametrosUsados;
  const res = sim.resultado?.dias[dia];
  if (!res || !p) {
    return (
      <>
        <Titulo>Gantt</Titulo>
        <div className="panel p-6">
          <p className="mb-3 text-muted-foreground">Necesitás una simulación para ver el Gantt.</p>
          <SimControles />
        </div>
      </>
    );
  }
  const r = res.replicas[Math.min(rep, res.replicas.length - 1)];
  const ap = p.horarios[dia].apertura;
  const minutos = Math.ceil(r.finJornada / 30) * 30;
  // Con el zoom mínimo, el gráfico llena todo el ancho disponible
  const z = Math.max(zoom, anchoCaja > 0 ? (anchoCaja - PAD - 16) / minutos : 0);
  const ancho = minutos * z;
  // Autos perdidos cercanos (< 14 px) se agrupan en una sola marca con número
  const grupos: Perdido[][] = [];
  for (const pp of [...r.perdidos].sort((a, b) => a.t - b.t)) {
    const g = grupos.at(-1);
    if (g && (pp.t - g[0].t) * z < 14) g.push(pp);
    else grupos.push([pp]);
  }
  const nElev = p.elevadoresTaller;
  const filas = [...Array.from({ length: nElev }, (_, i) => `Elevador ${i + 1}`), "Balanceadora", "Perdidos"];
  const marcas = Array.from({ length: Math.floor(minutos / 30) + 1 }, (_, i) => i * 30);

  const etiqueta = (t: Trabajo, w: number) => {
    const s = p.servicios[t.servicio];
    if (w >= 90) return `${s.abreviatura} #${t.id + 1} · ${Math.round(t.fin - t.inicio)}′`;
    if (w >= 24) return s.abreviatura;
    return "";
  };

  return (
    <>
      <Titulo sub="Tocá una barra para ver el detalle. Deslizá para recorrer la mañana.">Gantt de una réplica</Titulo>
      <div className="panel mb-3 flex flex-wrap items-end gap-3 p-3">
        <label className="w-40">
          <span className="etiqueta">Día</span>
          <select className="campo" value={dia} onChange={(e) => { setDia(e.target.value as DiaTipo); setSel(null); }}>
            <option value="sabado">Sábado</option>
            <option value="semana">Día de semana</option>
          </select>
        </label>
        <label className="w-28">
          <span className="etiqueta">Réplica</span>
          <select className="campo" value={rep} onChange={(e) => { setRep(Number(e.target.value)); setSel(null); }}>
            {res.replicas.map((_, i) => <option key={i} value={i}>{i + 1}</option>)}
          </select>
        </label>
        <div className="flex gap-1">
          <Boton variante="secundario" tam="chico" aria-label="Alejar" onClick={() => setZoom((z) => Math.max(1, z - 1))}><ZoomOut className="size-4" /></Boton>
          <Boton variante="secundario" tam="chico" aria-label="Acercar" onClick={() => setZoom((z) => Math.min(12, z + 1))}><ZoomIn className="size-4" /></Boton>
        </div>
        <div className="tablero text-sm text-muted-foreground">
          {r.atendidos} atendidos · <span className="text-alerta">{r.perdidos.length} perdidos · {pesos(r.ingresoPerdido)}</span>
        </div>
      </div>

      <div className="panel overflow-hidden">
        <div className="flex">
          <div className="shrink-0 border-r bg-card" style={{ width: COL }}>
            <div style={{ height: 28 }} />
            {filas.map((f) => (
              <div key={f} className={`flex items-center border-t px-2 font-display text-sm uppercase ${f === "Perdidos" ? "text-alerta" : ""}`} style={{ height: FILA }}>{f}</div>
            ))}
          </div>
          <div ref={caja} className="min-w-0 flex-1 overflow-x-auto" style={{ touchAction: "pan-x pan-y" }}>
            <div className="relative" style={{ width: ancho + PAD + 16 }}>
              <div className="relative" style={{ height: 28 }}>
                {marcas.map((m) => (
                  <span key={m} className="tablero absolute top-1 -translate-x-1/2 text-xs text-muted-foreground" style={{ left: m * z + PAD }}>{m % 60 === 0 || z >= 3 ? hhmm(ap, m) : ""}</span>
                ))}
              </div>
              {marcas.map((m) => (
                <div key={`l${m}`} className={`absolute bottom-0 border-l ${m % 60 === 0 ? "border-border" : "border-border/40"}`} style={{ left: m * z + PAD, top: 28 }} />
              ))}
              <div className="absolute bottom-0 border-l-2 border-dashed border-primary" style={{ left: r.horizonte * z + PAD, top: 28 }} title="Cierre" />
              {filas.map((f, fi) => (
                <div key={f} className="relative border-t" style={{ height: FILA }}>
                  {fi < nElev &&
                    r.traza.filter((t) => t.elevador === fi).map((t) => {
                      const w = (t.fin - t.inicio) * z;
                      const s = p.servicios[t.servicio];
                      return (
                        <button key={t.id} onClick={() => setSel({ tipo: "t", x: t })} title={`${s.nombre} · ${hhmm(ap, t.inicio)}–${hhmm(ap, t.fin)}`} className={`absolute top-1.5 overflow-hidden whitespace-nowrap rounded-sm border px-1 text-left font-display text-xs font-semibold ${t.usaBalanceadora ? "border-primary bg-primary/25 text-foreground" : "border-info bg-info/30 text-foreground"} ${sel?.tipo === "t" && sel.x.id === t.id ? "ring-2 ring-primary" : ""}`} style={{ left: t.inicio * z + PAD, width: Math.max(2, w - 1), height: FILA - 12 }}>
                          {etiqueta(t, w)}
                        </button>
                      );
                    })}
                  {fi === nElev &&
                    r.traza.filter((t) => t.usaBalanceadora).map((t) => {
                      const w = (t.fin - t.inicio) * z;
                      return (
                        <button key={t.id} onClick={() => setSel({ tipo: "t", x: t })} className="absolute top-1.5 overflow-hidden whitespace-nowrap rounded-sm border border-primary bg-primary/60 px-1 font-display text-xs font-semibold text-primary-foreground" style={{ left: t.inicio * z + PAD, width: Math.max(2, w - 1), height: FILA - 12 }}>
                          {w >= 40 ? `E${t.elevador + 1}` : ""}
                        </button>
                      );
                    })}
                  {fi === nElev + 1 &&
                    grupos.map((g) =>
                      g.length === 1 ? (
                        <button key={g[0].id} onClick={() => setSel({ tipo: "p", x: g[0] })} aria-label={`Auto perdido ${hhmm(ap, g[0].t)}`} className="absolute top-2 h-7 w-2.5 -translate-x-1/2 rounded-sm bg-alerta" style={{ left: g[0].t * z + PAD }} />
                      ) : (
                        <button key={g[0].id} onClick={() => setSel({ tipo: "g", x: g })} aria-label={`${g.length} autos perdidos desde ${hhmm(ap, g[0].t)}`} className="tablero absolute top-2 h-7 min-w-7 -translate-x-1/2 rounded-sm bg-alerta px-1 text-xs font-bold text-alerta-foreground" style={{ left: g[0].t * z + PAD }}>
                          ×{g.length}
                        </button>
                      ),
                    )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="panel mt-3 min-h-16 p-3">
        {!sel && <p className="text-sm text-muted-foreground">Tocá un trabajo o un auto perdido.</p>}
        {sel?.tipo === "t" && (
          <div className="tablero text-base">
            <div className="text-lg font-semibold">{p.servicios[sel.x.servicio].nombre} · auto #{sel.x.id + 1}</div>
            Llegó {hhmm(ap, sel.x.llegada)} · empezó {hhmm(ap, sel.x.inicio)} · terminó {hhmm(ap, sel.x.fin)} · elevador {sel.x.elevador + 1}
            <div className="text-muted-foreground">Esperó {num(sel.x.inicio - sel.x.llegada)} min · duró {num(sel.x.fin - sel.x.inicio)} min{sel.x.usaBalanceadora ? " · usó balanceadora" : ""}</div>
          </div>
        )}
        {sel?.tipo === "g" && (
          <div className="tablero text-base text-alerta">
            <div className="text-lg font-semibold">{sel.x.length} autos perdidos</div>
            <ul className="mt-1 space-y-1">
              {sel.x.map((pp) => (
                <li key={pp.id}>
                  <button className="text-left underline-offset-2 hover:underline" onClick={() => setSel({ tipo: "p", x: pp })}>
                    #{pp.id + 1} · {hhmm(ap, pp.t)} · {p.servicios[pp.servicio].nombre} · {pesos(pp.precio)}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
        {sel?.tipo === "p" && (
          <div className="tablero text-base text-alerta">
            <div className="text-lg font-semibold">Auto perdido #{sel.x.id + 1}</div>
            Llegó {hhmm(ap, sel.x.t)}, vio la fila y se fue · {p.servicios[sel.x.servicio].nombre} · {pesos(sel.x.precio)}
          </div>
        )}
      </div>
      <p className="mt-2 text-xs text-muted-foreground">{DIAS[dia]} · semilla {r.semilla} · línea punteada = cierre</p>
    </>
  );
}
