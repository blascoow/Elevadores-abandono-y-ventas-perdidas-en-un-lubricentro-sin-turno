import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Dato, Titulo } from "@/components/AppShell";
import { SimControles } from "@/components/SimControles";
import { validarReplicas } from "@/engine/validar";
import { DIAS, franja, num, pct, pesos } from "@/lib/formato";
import { meta } from "@/lib/meta";
import { cambiar, setOpciones, useStore } from "@/lib/store";
import type { DiaTipo } from "@/config/catalogo";

export const Route = createFileRoute("/simular")({
  head: () => meta("Simular", "Elegí semilla, réplicas, modo de duración, K y elevadores por franja, y simulá el sábado."),
  component: Simular,
});

function Simular() {
  const o = useStore((e) => e.opciones);
  const p = useStore((e) => e.parametros);
  const sim = useStore((e) => e.sim);
  const [repTexto, setRepTexto] = useState(String(o.replicas));
  const errRep = validarReplicas(Number(repTexto));
  const h = p.horarios[o.dia];
  const elev = p.elevadores[o.dia];
  const res = sim.resultado?.dias[o.dia];

  const setElev = (i: number, v: number) => {
    const n = [...elev];
    n[i] = v;
    cambiar(`elevadores.${o.dia}`, n, `Elevadores ${DIAS[o.dia].toLowerCase()} ${franja(h.apertura + i)}: ${v}`);
  };

  return (
    <>
      <Titulo sub="Se corren las réplicas del sábado y del día de semana en segundo plano.">Simular</Titulo>
      <div className="grid gap-4 lg:grid-cols-[minmax(0,380px)_1fr]">
        <section className="panel space-y-3 p-4">
          <div className="grid grid-cols-2 gap-3">
            <label className="col-span-2">
              <span className="etiqueta">Día</span>
              <select className="campo" value={o.dia} onChange={(e) => setOpciones({ dia: e.target.value as DiaTipo })}>
                <option value="sabado">Sábado</option>
                <option value="semana">Día de semana</option>
              </select>
            </label>
            <label>
              <span className="etiqueta">Semilla</span>
              <input className="campo" type="number" inputMode="numeric" value={o.semilla} onChange={(e) => setOpciones({ semilla: Math.trunc(Number(e.target.value) || 0) })} />
            </label>
            <label>
              <span className="etiqueta">Réplicas</span>
              <input
                className="campo"
                type="number"
                inputMode="numeric"
                value={repTexto}
                onChange={(e) => {
                  setRepTexto(e.target.value);
                  const n = Number(e.target.value);
                  if (!validarReplicas(n)) setOpciones({ replicas: n });
                }}
              />
            </label>
            {errRep && <p className="col-span-2 text-sm font-semibold text-primary">{errRep}</p>}
            <label className="col-span-2">
              <span className="etiqueta">Duraciones</span>
              <select className="campo" value={o.modo} onChange={(e) => setOpciones({ modo: e.target.value as "erlang" })}>
                <option value="realista">Triangular</option>
                <option value="erlang">Exponencial</option>
              </select>
            </label>
            <label>
              <span className="etiqueta">Fila</span>
              <select className="campo" value={o.politica} onChange={(e) => setOpciones({ politica: e.target.value as "fifo" })}>
                <option value="salteo">Con salteo</option>
                <option value="fifo">FIFO estricto</option>
              </select>
            </label>
            <label className="col-span-2">
              <span className="etiqueta">K: se van si ven esta cantidad esperando</span>
              <input className="campo" type="number" min={1} max={30} value={p.K} onChange={(e) => {
                const k = Math.trunc(Number(e.target.value));
                if (k >= 1 && k <= 30) cambiar("K", k, `K = ${k}`);
              }} />
            </label>
          </div>
          <div>
            <div className="etiqueta mb-1">Elevadores por franja · {DIAS[o.dia]}</div>
            <div className="grid grid-cols-1 gap-1.5">
              {elev.map((v, i) => (
                <div key={i} className="flex items-center justify-between gap-2">
                  <span className="tablero text-base">{franja(h.apertura + i)}</span>
                  <div className="flex gap-1">
                    {Array.from({ length: p.elevadoresTaller + 1 }, (_, c) => (
                      <button key={c} onClick={() => setElev(i, c)} className={`tablero size-9 rounded-sm border text-lg ${v === c ? "border-primary bg-primary text-primary-foreground" : "bg-background"}`} aria-pressed={v === c} aria-label={`${c} ${c === 1 ? "elevador" : "elevadores"} de ${franja(h.apertura + i)}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <SimControles deshabilitado={!!errRep} />
        </section>

        <section className="space-y-3">
          {!res ? (
            <div className="panel p-6 text-muted-foreground">Todavía no hay resultados. Tocá «Simular».</div>
          ) : (
            <>
              <h2 className="text-2xl font-semibold uppercase">Resultados · {DIAS[o.dia]}</h2>
              <p className="text-xs text-muted-foreground">Promedio ± intervalo de confianza del 95 % sobre {res.replicas.length} réplicas.</p>
              <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
                <Dato etiqueta="Ingreso perdido" valor={pesos(res.ingresoPerdido.media)} extra={`± ${pesos(res.ingresoPerdido.ic)}`} tono="alerta" />
                <Dato etiqueta="Autos perdidos" valor={num(res.perdidos.media)} extra={`± ${num(res.perdidos.ic)} · mín ${res.perdidos.min} máx ${res.perdidos.max}`} tono="alerta" />
                <Dato etiqueta="Atendidos" valor={num(res.atendidos.media)} extra={`± ${num(res.atendidos.ic)}`} tono="info" />
                <Dato etiqueta="Espera media" valor={`${num(res.esperaMedia.media)} min`} extra={`± ${num(res.esperaMedia.ic)}`} tono="info" />
              </div>
              <div className="panel p-4">
                <div className="etiqueta mb-2">Ocupación</div>
                {[...res.ocupacionElevadores.map((x, i) => [`Elevador ${i + 1}`, x] as const), ["Balanceadora", res.ocupacionBalanceadora] as const].map(([n, x]) => (
                  <div key={n} className="mb-1.5 flex items-center gap-2">
                    <span className="w-28 shrink-0 text-sm">{n}</span>
                    <div className="h-3 flex-1 rounded-sm bg-secondary">
                      <div className="h-full rounded-sm bg-info" style={{ width: `${Math.min(100, x * 100)}%` }} />
                    </div>
                    <span className="tablero w-12 text-right">{pct(x)}</span>
                  </div>
                ))}
              </div>
              <div className="panel overflow-x-auto p-4">
                <table className="tablero w-full text-right">
                  <thead className="etiqueta">
                    <tr><th className="text-left">Franja</th><th>Perdidos</th><th>Monto</th></tr>
                  </thead>
                  <tbody>
                    {res.perdidosPorHora.map((x, i) => (
                      <tr key={i} className="border-t">
                        <td className="py-1.5 text-left">{franja((sim.parametrosUsados?.horarios[o.dia].apertura ?? 8) + i)}</td>
                        <td className="text-alerta">{num(x)}</td>
                        <td className="text-alerta">{pesos(res.ingresoPerdidoPorHora[i])}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {res.alCierre > 0 && <p className="mt-2 text-xs text-muted-foreground">Llegó al cierre: {num(res.alCierre, 2)} por día</p>}
              </div>
            </>
          )}
        </section>
      </div>
    </>
  );
}
