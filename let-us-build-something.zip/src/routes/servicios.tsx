import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useDeferredValue, useMemo, useState } from "react";
import { Titulo } from "@/components/AppShell";
import { Boton } from "@/components/Boton";
import { SERVICIOS } from "@/config/catalogo";
import { num, pesos } from "@/lib/formato";
import { meta } from "@/lib/meta";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/servicios")({
  head: () => meta("Servicios históricos", "Los servicios históricos de ejemplo del lubricentro, con buscador y filtros."),
  component: Servicios,
});

const ALTO = 72;
/** Alcanza para pantallas altas; la lista ocupa al menos el 60 % del alto */
const ALTO_VISTA = 1400;

/** Minúsculas, sin tildes ni espacios: "FSV 200" → "fsv200" */
export function normalizar(t: string): string {
  return t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, "").toLowerCase();
}

function Servicios() {
  const historicos = useStore((e) => e.historicos);
  const generando = useStore((e) => e.generandoHistoricos);
  const [q, setQ] = useState("");
  const [serv, setServ] = useState("");
  const [elev, setElev] = useState("");
  const [anio, setAnio] = useState("");
  const [scroll, setScroll] = useState(0);
  const dq = useDeferredValue(normalizar(q));

  const filtrados = useMemo(() => {
    if (!historicos) return [];
    return historicos
      .filter((r) => (!serv || r.servicioId === serv) && (!elev || r.elevador === Number(elev)) && (!anio || r.fecha.startsWith(anio)) && (!dq || normalizar(r.patente).includes(dq) || normalizar(r.servicio).includes(dq)))
      .sort((a, b) => (a.fecha < b.fecha ? 1 : a.fecha > b.fecha ? -1 : 0));
  }, [historicos, serv, elev, anio, dq]);

  const total = filtrados.reduce((s, r) => s + r.precio, 0);
  const desde = Math.max(0, Math.floor(scroll / ALTO) - 8);
  const hasta = Math.min(filtrados.length, desde + Math.ceil(ALTO_VISTA / ALTO) + 16);

  return (
    <>
      <Titulo sub="Datos de ejemplo inventados con semilla fija.">Servicios históricos</Titulo>
      <div className="panel mb-3 grid grid-cols-2 gap-2 p-3 sm:grid-cols-4">
        <label className="relative col-span-2 sm:col-span-1">
          <span className="etiqueta">Buscar</span>
          <Search className="pointer-events-none absolute bottom-3 left-2.5 size-4 text-muted-foreground" />
          <input className="campo pl-8" placeholder="Patente o servicio" value={q} onChange={(e) => setQ(e.target.value)} />
        </label>
        <label>
          <span className="etiqueta">Servicio</span>
          <select className="campo" value={serv} onChange={(e) => setServ(e.target.value)}>
            <option value="">Todos</option>
            {SERVICIOS.map((s) => <option key={s.id} value={s.id}>{s.nombre}</option>)}
          </select>
        </label>
        <label>
          <span className="etiqueta">Elevador</span>
          <select className="campo" value={elev} onChange={(e) => setElev(e.target.value)}>
            <option value="">Todos</option>
            {[1, 2, 3, 4].map((x) => <option key={x} value={x}>{x}</option>)}
          </select>
        </label>
        <label>
          <span className="etiqueta">Año</span>
          <select className="campo" value={anio} onChange={(e) => setAnio(e.target.value)}>
            <option value="">Todos</option>
            {["2024", "2025", "2026"].map((x) => <option key={x} value={x}>{x}</option>)}
          </select>
        </label>
      </div>

      <div className="tablero mb-2 text-sm text-muted-foreground">
        {historicos ? `${filtrados.length.toLocaleString("es-AR")} de ${historicos.length.toLocaleString("es-AR")} servicios · ${pesos(total)}` : generando ? "Generando datos de ejemplo…" : "Cargando…"}
      </div>

      {historicos && filtrados.length === 0 && (
        <div className="panel mb-3 space-y-3 p-4">
          <p className="text-muted-foreground">No hay servicios que coincidan con la búsqueda</p>
          <Boton variante="secundario" onClick={() => { setQ(""); setServ(""); setElev(""); setAnio(""); }}>Limpiar filtros</Boton>
        </div>
      )}
      <div className="panel overflow-y-auto" style={{ height: "max(60vh, 420px)", contain: "strict" }} onScroll={(e) => setScroll(e.currentTarget.scrollTop)}>
        <div className="relative" style={{ height: filtrados.length * ALTO }}>
          {filtrados.slice(desde, hasta).map((r, i) => (
            <div key={r.id} className="absolute inset-x-0 flex items-center gap-3 border-b px-3" style={{ top: (desde + i) * ALTO, height: ALTO }}>
              <div className="tablero w-24 shrink-0 sm:w-28 rounded-sm border-2 border-foreground/80 bg-foreground px-1 text-center text-sm font-bold text-background">{r.patente}</div>
              <div className="min-w-0 flex-1">
                <div className="line-clamp-2 text-sm leading-tight">{r.servicio}</div>
                <div className="tablero text-xs text-muted-foreground">
                  {new Date(r.fecha).toLocaleString("es-AR", { dateStyle: "short", timeStyle: "short", timeZone: "America/Argentina/Buenos_Aires" })} · E{r.elevador} · {num(r.duracion, 0)}′
                </div>
              </div>
              <div className="tablero shrink-0 text-right text-base text-info">{pesos(r.precio)}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
