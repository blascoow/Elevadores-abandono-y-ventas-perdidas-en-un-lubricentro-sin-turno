import { createFileRoute } from "@tanstack/react-router";
import { Lock, RotateCcw, Trash2 } from "lucide-react";
import { useState } from "react";
import { Titulo } from "@/components/AppShell";
import { Boton } from "@/components/Boton";
import { CLAVE_PANEL_HASH, CLAVE_PANEL_SAL, REGLA_CONFLICTOS, REGLA_DOTACION } from "@/config/catalogo";
import { meta } from "@/lib/meta";
import { borrarHistorial, cambiar, reiniciarHistoricos, setOpciones, useStore } from "@/lib/store";

export const Route = createFileRoute("/panel")({
  head: () => meta("Panel", "Panel protegido con clave: reinicio de datos de ejemplo y ajustes avanzados."),
  component: Panel,
});

async function hashClave(clave: string): Promise<string> {
  const datos = new TextEncoder().encode(`${CLAVE_PANEL_SAL}:${clave}`);
  const buf = await crypto.subtle.digest("SHA-256", datos);
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join("");
}

function Panel() {
  const [ok, setOk] = useState(false);
  const [clave, setClave] = useState("");
  const [err, setErr] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const p = useStore((e) => e.parametros);
  const o = useStore((e) => e.opciones);
  const generando = useStore((e) => e.generandoHistoricos);
  const sinIDB = useStore((e) => e.sinIDB);

  if (!ok) {
    return (
      <>
        <Titulo>Panel</Titulo>
        <form
          className="panel max-w-sm space-y-3 p-4"
          onSubmit={async (e) => {
            e.preventDefault();
            if ((await hashClave(clave)) === CLAVE_PANEL_HASH) setOk(true);
            else setErr(true);
          }}
        >
          <label className="block">
            <span className="etiqueta">Clave</span>
            <input type="password" aria-label="Clave" id="clave-panel" className="campo" value={clave} onChange={(e) => { setClave(e.target.value); setErr(false); }} autoComplete="current-password" />
          </label>
          {err && <p className="text-sm font-semibold text-primary">Clave incorrecta</p>}
          <Boton type="submit"><Lock className="size-4" /> Entrar</Boton>
        </form>
      </>
    );
  }

  return (
    <>
      <Titulo sub="Ajustes avanzados del taller.">Panel</Titulo>
      <div className="grid gap-4 md:grid-cols-2">
        <section className="panel space-y-3 p-4">
          <h2 className="text-xl font-semibold uppercase">Datos de ejemplo</h2>
          <p className="text-sm text-muted-foreground">Regenera los {sinIDB ? "2.000" : "26.000"} servicios históricos inventados y vuelve el catálogo a fábrica (queda registrado en el historial).</p>
          <Boton
            disabled={generando}
            onClick={async () => {
              if (!confirm("¿Reiniciar los datos de ejemplo?")) return;
              await reiniciarHistoricos(true);
              setMsg("Datos de ejemplo reiniciados");
            }}
          >
            <RotateCcw className="size-4" /> {generando ? "Generando…" : "Reiniciar datos de ejemplo"}
          </Boton>
          <Boton
            variante="secundario"
            onClick={async () => {
              if (!confirm("¿Borrar todo el historial de cambios? No se puede deshacer.")) return;
              await borrarHistorial();
              setMsg("Historial borrado");
            }}
          >
            <Trash2 className="size-4" /> Borrar historial
          </Boton>
          {msg && <p className="text-sm font-semibold text-info">{msg}</p>}
        </section>

        <section className="panel space-y-3 p-4">
          <h2 className="text-xl font-semibold uppercase">Ajustes avanzados</h2>
          <label className="block">
            <span className="etiqueta">Elevadores del taller</span>
            <input className="campo" type="number" min={1} max={10} value={p.elevadoresTaller} onChange={(e) => {
              const v = Math.trunc(Number(e.target.value));
              if (v >= 1 && v <= 10) cambiar("elevadoresTaller", v, `Elevadores del taller: ${v}`);
            }} />
          </label>
          <label className="block">
            <span className="etiqueta">K (abandono)</span>
            <input className="campo" type="number" min={1} max={30} value={p.K} onChange={(e) => {
              const v = Math.trunc(Number(e.target.value));
              if (v >= 1 && v <= 30) cambiar("K", v, `K = ${v}`);
            }} />
          </label>
          <label className="block">
            <span className="etiqueta">Semilla de simulación</span>
            <input className="campo" type="number" value={o.semilla} onChange={(e) => setOpciones({ semilla: Math.trunc(Number(e.target.value) || 0) })} />
          </label>
          <div className="tablero space-y-1 text-sm text-muted-foreground">
            <div>Regla de dotación: P(espera &gt; {REGLA_DOTACION.esperaObjetivoMin} min) ≤ {REGLA_DOTACION.probMaxima * 100} %</div>
            <div>Regla de conflictos: {REGLA_CONFLICTOS === "ultimo-gana" ? "gana el cambio más reciente" : REGLA_CONFLICTOS}</div>
            <div>Guardado: {sinIDB ? "solo en memoria" : "en este navegador (IndexedDB)"}</div>
          </div>
          <Boton variante="fantasma" onClick={() => setOk(false)}><Lock className="size-4" /> Cerrar panel</Boton>
        </section>
      </div>
    </>
  );
}
