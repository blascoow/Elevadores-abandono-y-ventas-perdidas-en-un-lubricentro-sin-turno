/// <reference lib="webworker" />
import { ejecutarLote, type PedidoLote } from "@/engine/lote";

self.onmessage = (e: MessageEvent<PedidoLote>) => {
  let ultimo = 0;
  const res = ejecutarLote(e.data, (hechas, total) => {
    const ahora = performance.now();
    if (ahora - ultimo > 30 || hechas === total) {
      ultimo = ahora;
      (self as unknown as Worker).postMessage({ tipo: "progreso", hechas, total });
    }
  });
  (self as unknown as Worker).postMessage({ tipo: "fin", res });
};
