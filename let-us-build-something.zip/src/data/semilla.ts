// Generador de servicios históricos de EJEMPLO (inventados) con semilla fija.
import { HORARIOS, SERVICIOS, type DiaTipo } from "@/config/catalogo";
import { elegirServicio } from "@/engine/simulador";
import { mulberry32, triangular } from "@/engine/rng";

export interface RegistroHistorico {
  id: number;
  fecha: string; // ISO
  ts: number;
  patente: string;
  servicioId: string;
  servicio: string;
  precio: number;
  duracion: number;
  elevador: number;
}

const L = "ABCDEFGHJKLMNOPRSTUVWXYZ";

export function generarServiciosHistoricos(cantidad: number, semilla: number): RegistroHistorico[] {
  const r = mulberry32(semilla);
  const fin = Date.UTC(2026, 9, 31); // 31/10/2026
  const dias = 730;
  const out: RegistroHistorico[] = [];
  const letra = () => L[Math.floor(r() * L.length)];
  const dig = () => Math.floor(r() * 10);
  for (let i = 0; i < cantidad; i++) {
    // Sábados pesan más
    let d = Math.floor(r() * dias);
    let fecha = new Date(fin - d * 86400000);
    if (fecha.getUTCDay() === 0 || (fecha.getUTCDay() !== 6 && r() < 0.35)) {
      const hastaSab = (fecha.getUTCDay() + 1) % 7;
      d += hastaSab;
      fecha = new Date(fin - d * 86400000);
    }
    const tipo: DiaTipo = fecha.getUTCDay() === 6 ? "sabado" : "semana";
    const h = HORARIOS[tipo];
    const hora = h.apertura + r() * (h.cierre - h.apertura);
    const ts = fecha.getTime() + hora * 3600000 + 3 * 3600000; // hora de Argentina → UTC
    const s = SERVICIOS[elegirServicio(r(), SERVICIOS)];
    const avance = 1 - d / dias; // precios viejos más bajos (inflación)
    const precio = Math.round((s.precio * (0.35 + 0.65 * avance)) / 100) * 100;
    const patente = r() < 0.5 ? `${letra()}${letra()}${letra()} ${dig()}${dig()}${dig()}` : `${letra()}${letra()} ${dig()}${dig()}${dig()} ${letra()}${letra()}`;
    out.push({
      id: i + 1,
      fecha: new Date(ts).toISOString(),
      ts,
      patente,
      servicioId: s.id,
      servicio: s.nombre,
      precio,
      duracion: Math.round(triangular(r(), s.min, s.moda, s.max)),
      elevador: 1 + Math.floor(r() * 4),
    });
  }
  out.sort((a, b) => b.ts - a.ts);
  return out;
}
