import { estadisticas, promedioVectores } from "./estadistica";
import { simularReplica } from "./simulador";
import type { DiaTipo, HorarioDia, ModoDuracion, Politica, ResultadoReplica, ResumenDia, Servicio } from "./types";

export interface Parametros {
  servicios: Servicio[];
  horarios: Record<DiaTipo, HorarioDia>;
  elevadores: Record<DiaTipo, number[]>;
  K: number;
  elevadoresTaller: number;
}

export interface PedidoLote {
  parametros: Parametros;
  semilla: number;
  replicas: number;
  modo: ModoDuracion;
  politica: Politica;
  dias: DiaTipo[];
  /** Si es true, simula el sábado con 1..elevadoresTaller elevadores fijos todo el día */
  comparar: boolean;
}

export interface ComparacionC {
  c: number;
  resumen: ResumenDia;
}

export interface ResultadoLote {
  dias: Partial<Record<DiaTipo, ResumenDia>>;
  comparacion: ComparacionC[];
  duracionMs: number;
}

export function resumir(dia: DiaTipo, replicas: ResultadoReplica[]): ResumenDia {
  return {
    dia,
    replicas,
    atendidos: estadisticas(replicas.map((r) => r.atendidos)),
    perdidos: estadisticas(replicas.map((r) => r.perdidos.length)),
    ingresoPerdido: estadisticas(replicas.map((r) => r.ingresoPerdido)),
    esperaMedia: estadisticas(replicas.map((r) => r.esperaMedia)),
    perdidosPorHora: promedioVectores(replicas.map((r) => r.perdidosPorHora)),
    ingresoPerdidoPorHora: promedioVectores(replicas.map((r) => r.ingresoPerdidoPorHora)),
    ocupacionElevadores: promedioVectores(replicas.map((r) => r.ocupacionElevadores)),
    ocupacionBalanceadora: replicas.reduce((s, r) => s + r.ocupacionBalanceadora, 0) / Math.max(1, replicas.length),
    alCierre: replicas.reduce((s, r) => s + r.alCierre.length, 0) / Math.max(1, replicas.length),
  };
}

export function simularDia(pedido: PedidoLote, dia: DiaTipo, elevadoresPorHora: number[], conTraza: boolean, alAvanzar?: () => void): ResumenDia {
  const reps: ResultadoReplica[] = [];
  for (let k = 0; k < pedido.replicas; k++) {
    const r = simularReplica({
      servicios: pedido.parametros.servicios,
      horario: pedido.parametros.horarios[dia],
      elevadoresPorHora,
      K: pedido.parametros.K,
      modo: pedido.modo,
      politica: pedido.politica,
      semilla: pedido.semilla + k * 1000,
    });
    if (!conTraza) {
      r.traza = [];
      r.llegadas = [];
    }
    reps.push(r);
    alAvanzar?.();
  }
  return resumir(dia, reps);
}

export function limitarElevadores(v: number[], taller: number, horas: number): number[] {
  return Array.from({ length: horas }, (_, i) => Math.max(0, Math.min(taller, Math.round(v[i] ?? v[v.length - 1] ?? 1))));
}

export function ejecutarLote(pedido: PedidoLote, progreso?: (hechas: number, total: number) => void): ResultadoLote {
  const t0 = Date.now();
  const taller = pedido.parametros.elevadoresTaller;
  const total = pedido.replicas * (pedido.dias.length + (pedido.comparar ? taller : 0));
  let hechas = 0;
  const tick = () => {
    hechas++;
    progreso?.(hechas, total);
  };
  const dias: ResultadoLote["dias"] = {};
  for (const d of pedido.dias) {
    const h = pedido.parametros.horarios[d];
    dias[d] = simularDia(pedido, d, limitarElevadores(pedido.parametros.elevadores[d], taller, h.tasas.length), true, tick);
  }
  const comparacion: ComparacionC[] = [];
  if (pedido.comparar) {
    const n = pedido.parametros.horarios.sabado.tasas.length;
    for (let c = 1; c <= taller; c++) {
      comparacion.push({ c, resumen: simularDia(pedido, "sabado", Array(n).fill(c), false, tick) });
    }
  }
  return { dias, comparacion, duracionMs: Date.now() - t0 };
}

/** Por cada hora, mínima cantidad de elevadores fijos cuyo promedio de perdidos en esa hora no supera el umbral. */
export function recomendacionPorSimulacion(comp: ComparacionC[], umbral: number): (number | null)[] {
  if (comp.length === 0) return [];
  const horas = comp[0].resumen.perdidosPorHora.length;
  return Array.from({ length: horas }, (_, h) => {
    const ok = comp.find((x) => x.resumen.perdidosPorHora[h] <= umbral);
    return ok ? ok.c : null;
  });
}
