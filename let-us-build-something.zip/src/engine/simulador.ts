import { MinHeap } from "./heap";
import { exponencial, mulberry32, triangular } from "./rng";
import type { Llegada, ParamsSim, Perdido, ResultadoReplica, Servicio, Trabajo } from "./types";

/** Elige servicio por acumulado de probabilidades, en el orden del catálogo. */
export function elegirServicio(u: number, servicios: Servicio[]): number {
  const total = servicios.reduce((s, x) => s + x.mezcla, 0);
  let acc = 0;
  for (let i = 0; i < servicios.length; i++) {
    acc += servicios[i].mezcla / total;
    if (u < acc) return i;
  }
  return servicios.length - 1;
}

export function sortearDuracion(u: number, s: Servicio, modo: ParamsSim["modo"]): number {
  return modo === "erlang" ? exponencial(u, s.media) : triangular(u, s.min, s.moda, s.max);
}

/** Genera las llegadas del día. Devuelve las recibidas y las que llegaron justo al cierre. */
export function generarLlegadas(p: ParamsSim): { llegadas: Llegada[]; alCierre: Llegada[] } {
  const H = p.horario.tasas.length;
  const horizonte = H * 60;
  const llegadas: Llegada[] = [];
  const alCierre: Llegada[] = [];
  let id = 0;

  if (p.llegadasFijas) {
    const ord = [...p.llegadasFijas].sort((a, b) => a.t - b.t);
    for (const f of ord) {
      const l = { id: id++, t: f.t, servicio: f.servicio, duracion: f.duracion };
      if (f.t >= horizonte) {
        if (f.t === horizonte) alCierre.push(l);
        continue;
      }
      llegadas.push(l);
    }
    return { llegadas, alCierre };
  }

  const rL = mulberry32(p.semilla);
  const rS = mulberry32(p.semilla + 101);
  const rD = mulberry32(p.semilla + 202);
  for (let h = 0; h < H; h++) {
    const lambda = p.horario.tasas[h];
    if (!(lambda > 0)) continue;
    let t = h * 60;
    for (;;) {
      t += (-Math.log(1 - rL()) * 60) / lambda;
      if (t >= (h + 1) * 60) {
        if (h === H - 1 && t === horizonte) {
          const sv = elegirServicio(rS(), p.servicios);
          alCierre.push({ id: id++, t, servicio: sv, duracion: sortearDuracion(rD(), p.servicios[sv], p.modo) });
        }
        break;
      }
      const sv = elegirServicio(rS(), p.servicios);
      llegadas.push({ id: id++, t, servicio: sv, duracion: sortearDuracion(rD(), p.servicios[sv], p.modo) });
    }
  }
  return { llegadas, alCierre };
}

interface Ev {
  t: number;
  tipo: 0 | 1 | 2; // 0 fin, 1 cambio de hora, 2 llegada
  id: number;
  trabajo?: Trabajo;
  llegada?: Llegada;
}

export function simularReplica(p: ParamsSim): ResultadoReplica {
  const H = p.horario.tasas.length;
  const horizonte = H * 60;
  const nElev = Math.max(1, ...p.elevadoresPorHora);
  const { llegadas, alCierre } = generarLlegadas(p);

  const heap = new MinHeap<Ev>((a, b) => a.t - b.t || a.tipo - b.tipo || a.id - b.id);
  for (const l of llegadas) heap.push({ t: l.t, tipo: 2, id: l.id, llegada: l });
  for (let h = 1; h < H; h++) heap.push({ t: h * 60, tipo: 1, id: h });

  const elev: (Trabajo | null)[] = Array(nElev).fill(null);
  let bal: Trabajo | null = null;
  const cola: Llegada[] = [];
  const traza: Trabajo[] = [];
  const perdidos: Perdido[] = [];
  const perdidosPorHora = Array(H).fill(0);
  const ingresoPerdidoPorHora = Array(H).fill(0);
  const ocupElev = Array(nElev).fill(0);
  let ocupBal = 0;
  let atendidos = 0;
  let esperaTotal = 0;
  let finJornada = horizonte;

  const capacidad = (t: number) => {
    const h = Math.min(Math.max(0, Math.floor(t / 60)), H - 1);
    return Math.max(0, Math.min(nElev, p.elevadoresPorHora[h] ?? 0));
  };
  const elevLibre = (t: number) => {
    const c = capacidad(t);
    for (let i = 0; i < c; i++) if (!elev[i]) return i;
    return -1;
  };

  const asignar = (t: number) => {
    let progreso = true;
    while (progreso) {
      progreso = false;
      for (let i = 0; i < cola.length; i++) {
        const e = elevLibre(t);
        if (e < 0) return;
        const a = cola[i];
        const necesitaBal = p.servicios[a.servicio].usaBalanceadora;
        if (necesitaBal && bal) {
          if (p.politica === "fifo") return;
          continue;
        }
        const tr: Trabajo = { id: a.id, servicio: a.servicio, llegada: a.t, inicio: t, fin: t + a.duracion, elevador: e, usaBalanceadora: necesitaBal };
        elev[e] = tr;
        if (necesitaBal) bal = tr;
        esperaTotal += t - a.t;
        traza.push(tr);
        cola.splice(i, 1);
        heap.push({ t: tr.fin, tipo: 0, id: tr.id, trabajo: tr });
        progreso = true;
        break;
      }
    }
  };

  while (heap.size > 0) {
    const t = heap.peek()!.t;
    const arribos: Llegada[] = [];
    while (heap.size > 0 && heap.peek()!.t === t) {
      const ev = heap.pop()!;
      if (ev.tipo === 0) {
        const tr = ev.trabajo!;
        elev[tr.elevador] = null;
        if (bal === tr) bal = null;
        atendidos++;
        ocupElev[tr.elevador] += tr.fin - tr.inicio;
        if (tr.usaBalanceadora) ocupBal += tr.fin - tr.inicio;
        if (tr.fin > finJornada) finJornada = tr.fin;
      } else if (ev.tipo === 2) {
        arribos.push(ev.llegada!);
      }
    }
    asignar(t);
    for (const a of arribos) {
      if (cola.length >= p.K && elevLibre(t) < 0) {
        const s = p.servicios[a.servicio];
        const h = Math.min(Math.floor(a.t / 60), H - 1);
        perdidos.push({ id: a.id, t: a.t, servicio: a.servicio, servicioId: s.id, precio: s.precio, hora: h });
        perdidosPorHora[h]++;
        ingresoPerdidoPorHora[h] += s.precio;
        continue;
      }
      cola.push(a);
      asignar(t);
    }
  }

  return {
    semilla: p.semilla,
    atendidos,
    perdidos,
    alCierre,
    ingresoPerdido: perdidos.reduce((s, x) => s + x.precio, 0),
    ingresoPerdidoPorHora,
    perdidosPorHora,
    esperaMedia: atendidos > 0 ? esperaTotal / atendidos : 0,
    ocupacionElevadores: ocupElev.map((x) => x / finJornada),
    ocupacionBalanceadora: ocupBal / finJornada,
    traza,
    horizonte,
    finJornada,
    llegadas,
  };
}
