/** Generador mulberry32 exacto. Devuelve u en [0, 1). */
export function mulberry32(semilla: number): () => number {
  let a = semilla | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function exponencial(u: number, media: number): number {
  return -Math.log(1 - u) * media;
}

export function triangular(u: number, min: number, moda: number, max: number): number {
  if (max === min) return min;
  const F = (moda - min) / (max - min);
  if (u < F) return min + Math.sqrt(u * (max - min) * (moda - min));
  return max - Math.sqrt((1 - u) * (max - min) * (max - moda));
}
