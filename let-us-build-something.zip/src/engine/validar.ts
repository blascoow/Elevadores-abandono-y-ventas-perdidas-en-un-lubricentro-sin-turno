import type { Servicio } from "./types";

export const MSG_MIN_MODA = "El mínimo no puede ser mayor que la moda";
export const MSG_MODA_MAX = "La moda no puede ser mayor que el máximo";
export const MSG_PRECIO = "El precio tiene que ser un número mayor o igual a 0";
export const MSG_REPLICAS = "Elegí entre 5 y 100 réplicas";

export function validarTriangular(min: number, moda: number, max: number): string | null {
  if (![min, moda, max].every((x) => Number.isFinite(x) && x >= 0)) return "Las duraciones tienen que ser números positivos";
  if (min > moda) return MSG_MIN_MODA;
  if (moda > max) return MSG_MODA_MAX;
  return null;
}

export function formatearPorcentaje(x: number): string {
  return (Math.round(x * 100) / 100).toLocaleString("es-AR");
}

export function validarMezcla(mezclas: number[]): string | null {
  const suma = mezclas.reduce((s, x) => s + (Number.isFinite(x) ? x : 0), 0);
  if (Math.abs(suma - 100) > 1e-6) return `La mezcla suma ${formatearPorcentaje(suma)} %: tiene que dar 100 %`;
  return null;
}

/** Devuelve el precio válido o null si se rechaza. */
export function parsearPrecio(v: string | number | null | undefined): number | null {
  if (v === null || v === undefined) return null;
  if (typeof v === "string" && v.trim() === "") return null;
  const n = typeof v === "number" ? v : Number(v.replace(/\./g, "").replace(",", "."));
  if (!Number.isFinite(n) || n < 0) return null;
  return n;
}

export function validarReplicas(n: number): string | null {
  if (!Number.isInteger(n) || n < 5 || n > 100) return MSG_REPLICAS;
  return null;
}

export function validarServicio(s: Servicio): string | null {
  if (parsearPrecio(s.precio) === null) return MSG_PRECIO;
  return validarTriangular(s.min, s.moda, s.max);
}
