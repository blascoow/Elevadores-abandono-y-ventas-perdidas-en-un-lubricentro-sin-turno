import type { Parametros } from "./lote";

export type TipoEvento = "cambio" | "deshacer" | "rehacer" | "conflicto" | "reinicio";

export interface Evento {
  id: string;
  ts: number;
  tipo: TipoEvento;
  /** Ej.: "servicio.frenos.precio", "servicio.frenos.duracion", "mezcla", "tasas.sabado", "elevadores.sabado", "K", "elevadoresTaller" */
  ruta: string;
  valor: unknown;
  anterior: unknown;
  origen: string;
  /** Para deshacer/rehacer: id del cambio original. Para conflicto: id del cambio perdedor. */
  refId?: string;
  descripcion: string;
}

export function clonar<T>(x: T): T {
  return JSON.parse(JSON.stringify(x));
}

/** Igualdad por valor, sin importar el orden de las claves ni números escritos como texto. */
export function mismoValor(a: unknown, b: unknown): boolean {
  const norm = (x: unknown): unknown => {
    if (typeof x === "string" && x.trim() !== "" && Number.isFinite(Number(x))) return Number(x);
    if (Array.isArray(x)) return x.map(norm);
    if (x && typeof x === "object") return Object.fromEntries(Object.keys(x).sort().map((k) => [k, norm((x as Record<string, unknown>)[k])]));
    return x;
  };
  return JSON.stringify(norm(a)) === JSON.stringify(norm(b));
}

export function ordenar(evs: Evento[]): Evento[] {
  return [...evs].sort((a, b) => a.ts - b.ts || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
}

export function leerRuta(p: Parametros, ruta: string): unknown {
  const [a, b, c] = ruta.split(".");
  if (a === "servicio") {
    const s = p.servicios.find((x) => x.id === b);
    if (!s) return undefined;
    if (c === "duracion") return { media: s.media, min: s.min, moda: s.moda, max: s.max };
    return (s as unknown as Record<string, unknown>)[c];
  }
  if (a === "mezcla") return Object.fromEntries(p.servicios.map((s) => [s.id, s.mezcla]));
  if (a === "tasas") return [...p.horarios[b as "sabado"].tasas];
  if (a === "elevadores") return [...p.elevadores[b as "sabado"]];
  if (a === "K") return p.K;
  if (a === "elevadoresTaller") return p.elevadoresTaller;
  return undefined;
}

export function aplicarRuta(p: Parametros, ruta: string, valor: unknown): void {
  const [a, b, c] = ruta.split(".");
  if (a === "servicio") {
    const s = p.servicios.find((x) => x.id === b);
    if (!s) return;
    if (c === "duracion") Object.assign(s, valor as object);
    else (s as unknown as Record<string, unknown>)[c] = valor;
  } else if (a === "mezcla") {
    const m = valor as Record<string, number>;
    for (const s of p.servicios) if (m[s.id] !== undefined) s.mezcla = m[s.id];
  } else if (a === "tasas") p.horarios[b as "sabado"].tasas = [...(valor as number[])];
  else if (a === "elevadores") p.elevadores[b as "sabado"] = [...(valor as number[])];
  else if (a === "K") p.K = valor as number;
  else if (a === "elevadoresTaller") p.elevadoresTaller = valor as number;
}

/** Reconstruye los parámetros aplicando los eventos hasta `hasta` (inclusive). */
export function reconstruir(fabrica: Parametros, eventos: Evento[], hasta = Infinity): Parametros {
  const p = clonar(fabrica);
  for (const e of ordenar(eventos)) {
    if (e.ts > hasta) break;
    if (e.tipo === "reinicio") {
      Object.assign(p, clonar(fabrica));
      continue;
    }
    if (e.tipo === "conflicto") continue;
    aplicarRuta(p, e.ruta, e.valor);
  }
  return p;
}

export interface Pilas {
  deshacer: Evento[];
  rehacer: Evento[];
}

/** Pila de deshacer/rehacer derivada del historial. */
export function calcularPilas(eventos: Evento[]): Pilas {
  const deshacer: Evento[] = [];
  const rehacer: Evento[] = [];
  for (const e of ordenar(eventos)) {
    if (e.tipo === "cambio") {
      deshacer.push(e);
      rehacer.length = 0;
    } else if (e.tipo === "deshacer") {
      const i = deshacer.map((x) => x.id).lastIndexOf(e.refId!);
      if (i >= 0) rehacer.push(...deshacer.splice(i, 1));
    } else if (e.tipo === "rehacer") {
      const i = rehacer.map((x) => x.id).lastIndexOf(e.refId!);
      if (i >= 0) deshacer.push(...rehacer.splice(i, 1));
    } else if (e.tipo === "reinicio") {
      deshacer.length = 0;
      rehacer.length = 0;
    }
  }
  return { deshacer, rehacer };
}

export function crearDeshacer(original: Evento, id: string, ts: number, origen: string): Evento {
  return { id, ts, tipo: "deshacer", ruta: original.ruta, valor: clonar(original.anterior), anterior: clonar(original.valor), origen, refId: original.id, descripcion: `Deshacer: ${original.descripcion}` };
}

export function crearRehacer(original: Evento, id: string, ts: number, origen: string): Evento {
  return { id, ts, tipo: "rehacer", ruta: original.ruta, valor: clonar(original.valor), anterior: clonar(original.anterior), origen, refId: original.id, descripcion: `Rehacer: ${original.descripcion}` };
}

/**
 * Detecta conflicto entre un evento remoto y los locales (misma ruta, otra pestaña, dentro de la ventana).
 * Regla "ultimo-gana": gana el de marca de tiempo más reciente (empate: id mayor). Devuelve el par o null,
 * gane quien gane; la pestaña que recibe el cambio ajeno es la que lo registra.
 */
export function detectarConflicto(remoto: Evento, locales: Evento[], origenLocal: string, ventanaMs: number): { ganador: Evento; perdedor: Evento } | null {
  if (remoto.tipo === "conflicto" || remoto.tipo === "reinicio" || remoto.origen === origenLocal) return null;
  for (let i = locales.length - 1; i >= 0; i--) {
    const l = locales[i];
    if (l.origen !== origenLocal || l.ruta !== remoto.ruta || l.tipo === "conflicto" || l.tipo === "reinicio") continue;
    if (Math.abs(l.ts - remoto.ts) > ventanaMs) continue;
    if (JSON.stringify(l.valor) === JSON.stringify(remoto.valor)) continue;
    const localGana = l.ts > remoto.ts || (l.ts === remoto.ts && l.id > remoto.id);
    return localGana ? { ganador: l, perdedor: remoto } : { ganador: remoto, perdedor: l };
  }
  return null;
}

/** Id determinista para que las dos pestañas no registren dos veces el mismo conflicto. */
export function idConflicto(a: Evento, b: Evento): string {
  return `conf-${[a.id, b.id].sort().join("-")}`;
}

/** Nombre legible del dato que tocó el evento. */
export function nombreCampo(p: Parametros, ruta: string): string {
  const [a, b, c] = ruta.split(".");
  if (a === "servicio") {
    const s = p.servicios.find((x) => x.id === b);
    const n = s?.nombre ?? b;
    return c === "precio" ? `precio de ${n}` : c === "duracion" ? `duración de ${n}` : `${c} de ${n}`;
  }
  if (a === "mezcla") return "mezcla de servicios";
  if (a === "tasas") return `llegadas ${b === "sabado" ? "del sábado" : "de día de semana"}`;
  if (a === "elevadores") return `elevadores ${b === "sabado" ? "del sábado" : "de día de semana"}`;
  if (a === "K") return "K (abandono)";
  if (a === "elevadoresTaller") return "elevadores del taller";
  return ruta;
}

export function valorLegible(ruta: string, v: unknown): string {
  if (typeof v === "number") return ruta.endsWith(".precio") ? `$${Math.round(v).toLocaleString("es-AR")}` : String(v);
  if (Array.isArray(v)) return v.join("/");
  if (v && typeof v === "object") return Object.values(v as Record<string, unknown>).join("/");
  return String(v);
}

export function textoConflicto(p: Parametros, ganador: Evento, perdedor: Evento): string {
  return `Conflicto en ${nombreCampo(p, ganador.ruta)}: ganó ${valorLegible(ganador.ruta, ganador.valor)} (pestaña ${ganador.origen}) sobre ${valorLegible(perdedor.ruta, perdedor.valor)} (pestaña ${perdedor.origen})`;
}
