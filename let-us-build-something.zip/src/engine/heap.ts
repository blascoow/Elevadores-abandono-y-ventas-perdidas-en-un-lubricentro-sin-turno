/** Montículo binario mínimo propio. */
export class MinHeap<T> {
  private datos: T[] = [];
  constructor(private cmp: (a: T, b: T) => number) {}

  get size(): number {
    return this.datos.length;
  }

  peek(): T | undefined {
    return this.datos[0];
  }

  push(v: T): void {
    const d = this.datos;
    d.push(v);
    let i = d.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this.cmp(d[i], d[p]) >= 0) break;
      [d[i], d[p]] = [d[p], d[i]];
      i = p;
    }
  }

  pop(): T | undefined {
    const d = this.datos;
    if (d.length === 0) return undefined;
    const top = d[0];
    const last = d.pop()!;
    if (d.length > 0) {
      d[0] = last;
      let i = 0;
      const n = d.length;
      for (;;) {
        const l = 2 * i + 1;
        const r = l + 1;
        let m = i;
        if (l < n && this.cmp(d[l], d[m]) < 0) m = l;
        if (r < n && this.cmp(d[r], d[m]) < 0) m = r;
        if (m === i) break;
        [d[i], d[m]] = [d[m], d[i]];
        i = m;
      }
    }
    return top;
  }
}
