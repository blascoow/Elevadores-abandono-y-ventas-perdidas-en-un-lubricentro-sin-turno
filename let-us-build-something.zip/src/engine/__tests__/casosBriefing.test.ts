import { describe, it } from "vitest";

// Casos del briefing: se completan cuando lleguen los datos reales. NO inventar resultados.
describe("Caso A", () => {
  it.todo("Caso A — pendiente de datos del briefing");
});
describe("Caso B", () => {
  it.todo("Caso B — pendiente de datos del briefing");
});
describe("Caso C", () => {
  it.todo("Caso C — pendiente de datos del briefing");
});
describe("Caso D", () => {
  it.todo("Caso D — pendiente de datos del briefing");
});
