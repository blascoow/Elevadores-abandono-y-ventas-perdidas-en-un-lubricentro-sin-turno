import { describe, expect, it } from "vitest";
import { estadisticas, promedioVectores, tStudent95 } from "../estadistica";
import { calcularPilas, crearDeshacer, crearRehacer, detectarConflicto, idConflicto, mismoValor, leerRuta, textoConflicto, reconstruir, type Evento } from "../historial";
import { ejecutarLote, limitarElevadores, recomendacionPorSimulacion, type Parametros } from "../lote";
import { MSG_MIN_MODA, parsearPrecio, validarMezcla, validarReplicas, validarServicio, validarTriangular } from "../validar";
import { SERV } from "./helpers";

describe("validaciones", () => {
  it("mínimo mayor que moda", () => {
    expect(validarTriangular(30, 20, 40)).toBe(MSG_MIN_MODA);
    expect(validarTriangular(30, 20, 40)).toBe("El mínimo no puede ser mayor que la moda");
    expect(validarTriangular(10, 50, 40)).toBe("La moda no puede ser mayor que el máximo");
    expect(validarTriangular(NaN, 1, 2)).not.toBeNull();
    expect(validarTriangular(10, 20, 40)).toBeNull();
  });
  it("mezcla", () => {
    expect(validarMezcla([50, 40])).toBe("La mezcla suma 90 %: tiene que dar 100 %");
    expect(validarMezcla([50, 50.5])).toBe("La mezcla suma 100,5 %: tiene que dar 100 %");
    expect(validarMezcla([60, 40])).toBeNull();
  });
  it("precio negativo o vacío se rechaza", () => {
    expect(parsearPrecio("")).toBeNull();
    expect(parsearPrecio("  ")).toBeNull();
    expect(parsearPrecio("-5")).toBeNull();
    expect(parsearPrecio(-1)).toBeNull();
    expect(parsearPrecio(null)).toBeNull();
    expect(parsearPrecio("abc")).toBeNull();
    expect(parsearPrecio("45.000")).toBe(45000);
    expect(parsearPrecio(0)).toBe(0);
    expect(validarServicio({ ...SERV[0], precio: -3 })).not.toBeNull();
    expect(validarServicio(SERV[0])).toBeNull();
  });
  it("réplicas", () => {
    expect(validarReplicas(4)).toBe("Elegí entre 5 y 100 réplicas");
    expect(validarReplicas(101)).toBe("Elegí entre 5 y 100 réplicas");
    expect(validarReplicas(5.5)).toBe("Elegí entre 5 y 100 réplicas");
    expect(validarReplicas(30)).toBeNull();
  });
});

describe("estadística", () => {
  it("media e intervalo", () => {
    const e = estadisticas([1, 2, 3, 4, 5]);
    expect(e.media).toBe(3);
    expect(e.ic).toBeCloseTo((2.776 * Math.sqrt(2.5)) / Math.sqrt(5), 6);
    expect(estadisticas([]).media).toBe(0);
    expect(estadisticas([7]).ic).toBe(0);
    expect(tStudent95(0)).toBe(0);
    expect(tStudent95(45)).toBe(2.0);
    expect(tStudent95(500)).toBe(1.96);
    expect(promedioVectores([[1, 2], [3, 4]])).toEqual([2, 3]);
    expect(promedioVectores([])).toEqual([]);
  });
});

const fabrica: Parametros = {
  servicios: SERV.map((s) => ({ ...s })),
  horarios: { sabado: { apertura: 8, cierre: 13, tasas: [4, 6, 8, 7, 4] }, semana: { apertura: 8, cierre: 10, tasas: [2, 0] } },
  elevadores: { sabado: [2, 3, 3, 3, 2], semana: [1, 1] },
  K: 4,
  elevadoresTaller: 4,
};

describe("lote de réplicas", () => {
  it("semilla de réplica k = semilla + k·1000 y comparación", () => {
    const r = ejecutarLote({ parametros: fabrica, semilla: 5, replicas: 5, modo: "realista", politica: "salteo", dias: ["sabado", "semana"], comparar: true });
    expect(r.dias.sabado!.replicas.map((x) => x.semilla)).toEqual([5, 1005, 2005, 3005, 4005]);
    expect(r.comparacion.map((c) => c.c)).toEqual([1, 2, 3, 4]);
    expect(r.comparacion[0].resumen.perdidos.media).toBeGreaterThanOrEqual(r.comparacion[3].resumen.perdidos.media);
    const rec = recomendacionPorSimulacion(r.comparacion, 0.5);
    expect(rec.length).toBe(5);
    expect(recomendacionPorSimulacion([], 0.5)).toEqual([]);
  });
  it("limita elevadores al taller", () => {
    expect(limitarElevadores([9, -1, 2], 4, 4)).toEqual([4, 0, 2, 2]);
  });
});

let n = 0;
const ev = (p: Partial<Evento>): Evento => ({ id: String(++n).padStart(4, "0"), ts: n * 10, tipo: "cambio", ruta: "K", valor: 0, anterior: 0, origen: "A", descripcion: "", ...p });

describe("historial (event sourcing)", () => {
  it("reconstruye y respeta 'Estado al…'", () => {
    const e1 = ev({ ruta: "servicio.normal.precio", valor: 2000, anterior: 1000, ts: 100 });
    const e2 = ev({ ruta: "K", valor: 6, anterior: 4, ts: 200 });
    const e3 = ev({ ruta: "mezcla", valor: { normal: 50, balanceo: 50 }, anterior: {}, ts: 300 });
    const e4 = ev({ ruta: "servicio.balanceo.duracion", valor: { media: 1, min: 1, moda: 1, max: 1 }, anterior: {}, ts: 400 });
    const e5 = ev({ ruta: "tasas.sabado", valor: [1, 1, 1, 1, 1], ts: 500 });
    const e6 = ev({ ruta: "elevadores.semana", valor: [4, 4], ts: 600 });
    const e7 = ev({ ruta: "elevadoresTaller", valor: 6, ts: 700 });
    const todos = [e7, e6, e5, e4, e3, e2, e1];
    const p = reconstruir(fabrica, todos);
    expect(p.servicios[0].precio).toBe(2000);
    expect(p.K).toBe(6);
    expect(p.servicios.map((s) => s.mezcla)).toEqual([50, 50]);
    expect(p.servicios[1].max).toBe(1);
    expect(p.horarios.sabado.tasas).toEqual([1, 1, 1, 1, 1]);
    expect(p.elevadores.semana).toEqual([4, 4]);
    expect(p.elevadoresTaller).toBe(6);
    const antes = reconstruir(fabrica, todos, 150);
    expect(antes.servicios[0].precio).toBe(2000);
    expect(antes.K).toBe(4);
    expect(reconstruir(fabrica, todos, 50)).toEqual(fabrica);
    expect(fabrica.servicios[0].precio).toBe(1000);
    expect(leerRuta(p, "servicio.balanceo.duracion")).toEqual({ media: 1, min: 1, moda: 1, max: 1 });
    expect(leerRuta(p, "servicio.x.precio")).toBeUndefined();
    expect(leerRuta(p, "otra")).toBeUndefined();
    expect(leerRuta(p, "K")).toBe(6);
  });
  it("deshacer/rehacer más de 50 cambios y quedan en el historial", () => {
    const evs: Evento[] = [];
    let ts = 1000;
    for (let i = 1; i <= 60; i++) evs.push(ev({ ts: ts++, ruta: "K", valor: i, anterior: i - 1 }));
    for (let i = 0; i < 55; i++) {
      const top = calcularPilas(evs).deshacer.at(-1)!;
      evs.push(crearDeshacer(top, `u${String(i).padStart(3, "0")}`, ts++, "A"));
    }
    expect(reconstruir(fabrica, evs).K).toBe(5);
    expect(calcularPilas(evs).rehacer.length).toBe(55);
    const top = calcularPilas(evs).rehacer.at(-1)!;
    evs.push(crearRehacer(top, "r1", ts++, "A"));
    expect(reconstruir(fabrica, evs).K).toBe(6);
    expect(evs.filter((e) => e.tipo !== "cambio").length).toBe(56);
    evs.push(ev({ ts: ts++, ruta: "K", valor: 99, anterior: 6 }));
    expect(calcularPilas(evs).rehacer.length).toBe(0);
    evs.push(ev({ ts: ts++, tipo: "reinicio" }));
    expect(reconstruir(fabrica, evs).K).toBe(4);
    expect(calcularPilas(evs).deshacer.length).toBe(0);
  });
  it("conflicto: gana el más reciente y se registra una sola vez", () => {
    const local = ev({ ts: 5000, ruta: "servicio.normal.precio", valor: 3000, origen: "A" });
    const remotoViejo = ev({ ts: 4000, ruta: "servicio.normal.precio", valor: 2500, origen: "B" });
    const c = detectarConflicto(remotoViejo, [local], "A", 3000);
    expect(c?.ganador.id).toBe(local.id);
    expect(detectarConflicto(local, [remotoViejo], "B", 3000)?.ganador.id).toBe(local.id);
    expect(detectarConflicto({ ...remotoViejo, ruta: "K" }, [local], "A", 3000)).toBeNull();
    expect(detectarConflicto({ ...remotoViejo, ts: 0 }, [local], "A", 3000)).toBeNull();
    expect(detectarConflicto({ ...remotoViejo, valor: 3000 }, [local], "A", 3000)).toBeNull();
    expect(detectarConflicto({ ...remotoViejo, tipo: "conflicto" }, [local], "A", 3000)).toBeNull();
    const p = reconstruir(fabrica, [local, remotoViejo, { ...remotoViejo, id: "zz", tipo: "conflicto" }]);
    expect(p.servicios[0].precio).toBe(3000);
    expect(idConflicto(local, remotoViejo)).toBe(idConflicto(remotoViejo, local));
    expect(textoConflicto(fabrica, local, remotoViejo)).toMatch(/^Conflicto en precio de .+: ganó \$3\.000 \(pestaña A\) sobre \$2\.500 \(pestaña B\)$/);
  });
});

describe("mismo valor", () => {
  it("un cambio igual al valor actual no cuenta como cambio", () => {
    expect(mismoValor({ media: 30, min: 20, moda: 28, max: 45 }, { max: 45, moda: 28, min: 20, media: 30 })).toBe(true);
    expect(mismoValor(38000, "38000")).toBe(true);
    expect(mismoValor([1, 2], [1, 3])).toBe(false);
  });
});
