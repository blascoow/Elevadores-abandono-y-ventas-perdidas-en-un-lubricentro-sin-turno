import type { ParamsSim, Servicio } from "../types";

export const SERV: Servicio[] = [
  { id: "normal", nombre: "Normal", abreviatura: "N", precio: 1000, mezcla: 70, media: 30, min: 20, moda: 30, max: 40, usaBalanceadora: false },
  { id: "balanceo", nombre: "Balanceo", abreviatura: "B", precio: 500, mezcla: 30, media: 40, min: 30, moda: 40, max: 50, usaBalanceadora: true },
];

export function params(extra: Partial<ParamsSim> = {}): ParamsSim {
  return {
    servicios: SERV,
    horario: { apertura: 8, cierre: 13, tasas: [4, 6, 8, 7, 4] },
    elevadoresPorHora: [2, 2, 2, 2, 2],
    K: 4,
    modo: "realista",
    politica: "salteo",
    semilla: 42,
    ...extra,
  };
}
