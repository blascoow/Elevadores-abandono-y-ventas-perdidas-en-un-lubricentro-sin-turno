import { describe, expect, it } from "vitest";
import { dotacionPorHora, erlangC, esperaMediaErlang, mediaPonderada, probEsperaMayor, recomendarElevadores } from "../erlang";
import { SERV } from "./helpers";

describe("Erlang C contra valores conocidos", () => {
  it("c=1: P = a", () => expect(erlangC(1, 0.5)).toBeCloseTo(0.5, 10));
  it("c=2, a=1: 1/3", () => expect(erlangC(2, 1)).toBeCloseTo(1 / 3, 10));
  it("c=3, a=2: 4/9", () => expect(erlangC(3, 2)).toBeCloseTo(4 / 9, 10));
  it("c=10, a=8: 0.4092", () => expect(erlangC(10, 8)).toBeCloseTo(0.40918, 4));
  it("sin carga y saturado", () => {
    expect(erlangC(2, 0)).toBe(0);
    expect(erlangC(2, 2)).toBe(1);
    expect(esperaMediaErlang(1, 2, 1)).toBe(Infinity);
  });
  it("espera media M/M/1", () => {
    // λ=1, μ=2 → Wq = ρ/(μ−λ) = 0.5
    expect(esperaMediaErlang(1, 1, 2)).toBeCloseTo(0.5, 10);
  });
  it("probabilidad de esperar más de T", () => {
    expect(probEsperaMayor(1, 1, 2, 60)).toBeCloseTo(0.5 * Math.exp(-1), 10);
    expect(probEsperaMayor(1, 0, 2, 60)).toBe(0);
    expect(probEsperaMayor(1, 3, 2, 60)).toBe(1);
  });
});

describe("dotación", () => {
  const regla = { esperaObjetivoMin: 10, probMaxima: 0.2 };
  it("tasa 0 recomienda 1 elevador", () => expect(recomendarElevadores(0, 30, regla)).toBe(1));
  it("recomendación mínima que cumple la regla", () => {
    const c = recomendarElevadores(6, 30, regla);
    expect(probEsperaMayor(c, 6, 2, 10)).toBeLessThanOrEqual(0.2);
    expect(probEsperaMayor(c - 1, 6, 2, 10)).toBeGreaterThan(0.2);
    expect(c).toBe(5);
  });
  it("marca cuando supera el taller", () => {
    const filas = dotacionPorHora({ apertura: 8, cierre: 11, tasas: [0, 2, 12] }, SERV, regla, 4);
    expect(filas.map((f) => f.hora)).toEqual([8, 9, 10]);
    expect(filas[0].recomendado).toBe(0); // franja sin autos: Erlang C muestra 0
    expect(filas[0].superaTaller).toBe(false);
    expect(filas[2].superaTaller).toBe(true);
  });
  it("media ponderada por mezcla", () => {
    expect(mediaPonderada(SERV)).toBeCloseTo(0.7 * 30 + 0.3 * 40);
    expect(mediaPonderada([])).toBe(0);
  });
});
