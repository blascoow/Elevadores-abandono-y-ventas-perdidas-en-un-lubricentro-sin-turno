import { describe, expect, it } from "vitest";
import { MinHeap } from "../heap";
import { exponencial, mulberry32, triangular } from "../rng";
import { elegirServicio, generarLlegadas, simularReplica } from "../simulador";
import { params, SERV } from "./helpers";

describe("mulberry32", () => {
  it("reproduce la secuencia exacta de la fórmula", () => {
    const r = mulberry32(1);
    // valores de referencia de mulberry32(1)
    expect(r()).toBeCloseTo(0.6270739405881613, 12);
    expect(r()).toBeCloseTo(0.002735721180215478, 12);
  });
  it("triangular y exponencial", () => {
    expect(triangular(0, 10, 20, 40)).toBe(10);
    expect(triangular(1, 10, 20, 40)).toBe(40);
    expect(triangular(1 / 3, 10, 20, 40)).toBeCloseTo(20, 9);
    expect(triangular(0.5, 5, 5, 5)).toBe(5);
    expect(exponencial(0, 30)).toBeCloseTo(0);
    expect(exponencial(1 - Math.exp(-1), 30)).toBeCloseTo(30, 9);
  });
});

describe("montículo", () => {
  it("devuelve en orden", () => {
    const h = new MinHeap<number>((a, b) => a - b);
    [5, 1, 9, 3, 7, 2, 8].forEach((x) => h.push(x));
    const out: number[] = [];
    while (h.size) out.push(h.pop()!);
    expect(out).toEqual([1, 2, 3, 5, 7, 8, 9]);
    expect(h.pop()).toBeUndefined();
  });
});

describe("determinismo", () => {
  it("misma semilla = mismo sábado idéntico", () => {
    const a = simularReplica(params());
    const b = simularReplica(params());
    expect(JSON.stringify(a)).toBe(JSON.stringify(b));
    expect(a.llegadas.length).toBeGreaterThan(10);
  });
  it("otra semilla da otro sábado", () => {
    expect(JSON.stringify(simularReplica(params({ semilla: 1 })).llegadas)).not.toBe(JSON.stringify(simularReplica(params({ semilla: 2 })).llegadas));
  });
  it("cambiar solo las duraciones no altera la secuencia de llegadas", () => {
    const a = generarLlegadas(params({ modo: "realista" }));
    const b = generarLlegadas(params({ modo: "erlang" }));
    const otras = SERV.map((s) => ({ ...s, min: 1, moda: 2, max: 90, media: 77 }));
    const c = generarLlegadas(params({ servicios: otras }));
    const tiempos = (x: typeof a) => x.llegadas.map((l) => [l.t, l.servicio]);
    expect(tiempos(b)).toEqual(tiempos(a));
    expect(tiempos(c)).toEqual(tiempos(a));
    expect(a.llegadas.map((l) => l.duracion)).not.toEqual(c.llegadas.map((l) => l.duracion));
  });
});

describe("mezcla de servicios", () => {
  it("acumulado en orden del catálogo", () => {
    expect(elegirServicio(0, SERV)).toBe(0);
    expect(elegirServicio(0.69, SERV)).toBe(0);
    expect(elegirServicio(0.71, SERV)).toBe(1);
    expect(elegirServicio(0.9999999, SERV)).toBe(1);
  });
});

describe("abandono con K", () => {
  const fijas = (n: number) => Array.from({ length: n }, () => ({ t: 1, servicio: 0, duracion: 100 }));
  it("con K esperando y sin elevador libre se va", () => {
    // 1 elevador: 1 atendiéndose + 4 esperando; el 6.º se va
    const r = simularReplica(params({ elevadoresPorHora: [1, 1, 1, 1, 1], llegadasFijas: fijas(6) }));
    expect(r.perdidos.length).toBe(1);
    expect(r.perdidos[0].id).toBe(5);
    expect(r.atendidos).toBe(5);
  });
  it("con K−1 esperando se queda", () => {
    const r = simularReplica(params({ elevadoresPorHora: [1, 1, 1, 1, 1], llegadasFijas: fijas(5) }));
    expect(r.perdidos.length).toBe(0);
  });
  it("K configurable", () => {
    const r = simularReplica(params({ K: 1, elevadoresPorHora: [1, 1, 1, 1, 1], llegadasFijas: fijas(4) }));
    expect(r.perdidos.length).toBe(2);
  });
  it("no se va si hay elevador libre aunque la fila sea larga", () => {
    // 2 elevadores; balanceadora ocupada por el primero; los que necesitan balanceadora esperan con elevador libre
    const ll = [{ t: 0, servicio: 1, duracion: 100 }, ...Array.from({ length: 6 }, () => ({ t: 1, servicio: 1, duracion: 10 }))];
    const r = simularReplica(params({ K: 2, elevadoresPorHora: [2, 2, 2, 2, 2], llegadasFijas: ll }));
    expect(r.perdidos.length).toBe(0);
  });
});

describe("salteo por balanceadora vs FIFO estricto", () => {
  const ll = [
    { t: 0, servicio: 1, duracion: 60 }, // usa balanceadora, elevador 0
    { t: 1, servicio: 1, duracion: 30 }, // necesita balanceadora: espera
    { t: 2, servicio: 0, duracion: 20 }, // solo elevador
  ];
  it("con salteo el de atrás pasa adelante", () => {
    const r = simularReplica(params({ llegadasFijas: ll, politica: "salteo" }));
    const t2 = r.traza.find((x) => x.id === 2)!;
    expect(t2.inicio).toBe(2);
    expect(t2.elevador).toBe(1);
    expect(r.traza.find((x) => x.id === 1)!.inicio).toBe(60);
  });
  it("con FIFO estricto espera su turno", () => {
    const r = simularReplica(params({ llegadasFijas: ll, politica: "fifo" }));
    expect(r.traza.find((x) => x.id === 1)!.inicio).toBe(60);
    expect(r.traza.find((x) => x.id === 2)!.inicio).toBe(60);
    expect(r.traza.find((x) => x.id === 2)!.elevador).toBe(1);
  });
  it("elevador libre de número más bajo", () => {
    const r = simularReplica(params({ elevadoresPorHora: [4, 4, 4, 4, 4], llegadasFijas: [{ t: 0, servicio: 0, duracion: 10 }, { t: 0, servicio: 0, duracion: 50 }, { t: 20, servicio: 0, duracion: 5 }] }));
    expect(r.traza.map((x) => x.elevador)).toEqual([0, 1, 0]);
  });
});

describe("eventos simultáneos", () => {
  it("primero fines, después fila, después llegadas", () => {
    // 1 elevador. A ocupa 0-10. B llega en 5 y espera. C llega en 10 justo cuando termina A.
    const r = simularReplica(params({ elevadoresPorHora: [1, 1, 1, 1, 1], llegadasFijas: [{ t: 0, servicio: 0, duracion: 10 }, { t: 5, servicio: 0, duracion: 10 }, { t: 10, servicio: 0, duracion: 10 }] }));
    expect(r.traza.find((x) => x.id === 1)!.inicio).toBe(10);
    expect(r.traza.find((x) => x.id === 2)!.inicio).toBe(20);
  });
  it("el segundo que llega en el mismo instante ve la fila del primero", () => {
    // 1 elevador ocupado, 3 esperando, K=4: llegan 2 juntos; el primero se queda (3), el segundo ve 4 y se va
    const base = [{ t: 0, servicio: 0, duracion: 100 }, { t: 1, servicio: 0, duracion: 5 }, { t: 1, servicio: 0, duracion: 5 }, { t: 1, servicio: 0, duracion: 5 }];
    const r = simularReplica(params({ elevadoresPorHora: [1, 1, 1, 1, 1], llegadasFijas: [...base, { t: 2, servicio: 0, duracion: 5 }, { t: 2, servicio: 0, duracion: 5 }] }));
    expect(r.perdidos.map((p) => p.id)).toEqual([5]);
  });
  it("si un fin libera elevador en el mismo instante, la llegada no abandona", () => {
    const ll = [{ t: 0, servicio: 0, duracion: 10 }, ...Array.from({ length: 4 }, () => ({ t: 1, servicio: 0, duracion: 1 })), { t: 10, servicio: 0, duracion: 1 }];
    const r = simularReplica(params({ elevadoresPorHora: [1, 1, 1, 1, 1], llegadasFijas: ll }));
    expect(r.perdidos.length).toBe(0);
  });
});

describe("cierre exclusivo y tasa 0", () => {
  it("un auto que llega exactamente al cierre no se recibe", () => {
    const r = simularReplica(params({ llegadasFijas: [{ t: 299.9, servicio: 0, duracion: 10 }, { t: 300, servicio: 0, duracion: 10 }, { t: 310, servicio: 0, duracion: 10 }] }));
    expect(r.atendidos).toBe(1);
    expect(r.alCierre.map((x) => x.t)).toEqual([300]);
    expect(r.finJornada).toBeCloseTo(309.9);
  });
  it("tasa 0 = hora sin llegadas", () => {
    const r = simularReplica(params({ horario: { apertura: 8, cierre: 13, tasas: [5, 0, 5, 0, 5] }, semilla: 7 }));
    for (const l of r.llegadas) {
      const h = Math.floor(l.t / 60);
      expect(h === 1 || h === 3).toBe(false);
    }
    const nada = simularReplica(params({ horario: { apertura: 8, cierre: 13, tasas: [0, 0, 0, 0, 0] } }));
    expect(nada.llegadas.length).toBe(0);
    expect(nada.atendidos).toBe(0);
    expect(nada.esperaMedia).toBe(0);
  });
  it("al cambiar de hora se reinicia el sorteo desde el inicio de la hora", () => {
    const r = generarLlegadas(params({ horario: { apertura: 8, cierre: 13, tasas: [0, 0, 60, 0, 0] } }));
    expect(r.llegadas.every((l) => l.t >= 120 && l.t < 180)).toBe(true);
  });
  it("menos elevadores en una hora: no se asigna por encima de la capacidad", () => {
    const r = simularReplica(params({ elevadoresPorHora: [1, 3, 3, 3, 3], llegadasFijas: [{ t: 0, servicio: 0, duracion: 10 }, { t: 0, servicio: 0, duracion: 10 }] }));
    expect(r.traza.map((x) => x.inicio)).toEqual([0, 10]);
    const sube = simularReplica(params({ elevadoresPorHora: [0, 1, 1, 1, 1], llegadasFijas: [{ t: 5, servicio: 0, duracion: 10 }] }));
    expect(sube.traza[0].inicio).toBe(60);
  });
});

describe("ventas perdidas", () => {
  it("registra servicio, monto y hora", () => {
    const ll = [{ t: 0, servicio: 0, duracion: 200 }, ...Array.from({ length: 4 }, () => ({ t: 1, servicio: 0, duracion: 5 })), { t: 70, servicio: 1, duracion: 5 }, { t: 130, servicio: 0, duracion: 5 }];
    const r = simularReplica(params({ elevadoresPorHora: [1, 1, 1, 1, 1], llegadasFijas: ll }));
    expect(r.perdidos.map((p) => [p.servicioId, p.precio, p.hora])).toEqual([["balanceo", 500, 1], ["normal", 1000, 2]]);
    expect(r.ingresoPerdido).toBe(1500);
    expect(r.ingresoPerdidoPorHora).toEqual([0, 500, 1000, 0, 0]);
    expect(r.perdidosPorHora).toEqual([0, 1, 1, 0, 0]);
  });
  it("ocupación de elevadores y balanceadora", () => {
    const r = simularReplica(params({ llegadasFijas: [{ t: 0, servicio: 1, duracion: 150 }] }));
    expect(r.ocupacionElevadores[0]).toBeCloseTo(0.5);
    expect(r.ocupacionBalanceadora).toBeCloseTo(0.5);
    expect(r.esperaMedia).toBe(0);
  });
});
