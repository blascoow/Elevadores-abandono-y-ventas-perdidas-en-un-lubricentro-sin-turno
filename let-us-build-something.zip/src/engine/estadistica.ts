import type { Estad } from "./types";

// t de Student bilateral al 95 % (gl 1..30); para más se usa 1.96
const T95 = [12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228, 2.201, 2.179, 2.16, 2.145, 2.131, 2.12, 2.11, 2.101, 2.093, 2.086, 2.08, 2.074, 2.069, 2.064, 2.06, 2.056, 2.052, 2.048, 2.045, 2.042];

export function tStudent95(gl: number): number {
  if (gl < 1) return 0;
  if (gl <= 30) return T95[gl - 1];
  if (gl <= 60) return 2.0;
  return 1.96;
}

export function estadisticas(xs: number[]): Estad {
  const n = xs.length;
  if (n === 0) return { media: 0, ic: 0, min: 0, max: 0 };
  const media = xs.reduce((s, x) => s + x, 0) / n;
  const varianza = n > 1 ? xs.reduce((s, x) => s + (x - media) ** 2, 0) / (n - 1) : 0;
  return {
    media,
    ic: n > 1 ? (tStudent95(n - 1) * Math.sqrt(varianza)) / Math.sqrt(n) : 0,
    min: Math.min(...xs),
    max: Math.max(...xs),
  };
}

export function promedioVectores(vs: number[][]): number[] {
  if (vs.length === 0) return [];
  const len = Math.max(...vs.map((v) => v.length));
  const out = Array(len).fill(0);
  for (const v of vs) v.forEach((x, i) => (out[i] += x));
  return out.map((x) => x / vs.length);
}
