import type { DiaTipo, HorarioDia, Servicio } from "../config/catalogo";

export type { DiaTipo, HorarioDia, Servicio };

export type ModoDuracion = "erlang" | "realista";
export type Politica = "salteo" | "fifo";

export interface LlegadaFija {
  /** minutos desde la apertura */
  t: number;
  /** índice en el catálogo */
  servicio: number;
  /** duración en minutos */
  duracion: number;
}

export interface ParamsSim {
  servicios: Servicio[];
  horario: HorarioDia;
  elevadoresPorHora: number[];
  K: number;
  modo: ModoDuracion;
  politica: Politica;
  semilla: number;
  /** Para tests: reemplaza las llegadas aleatorias */
  llegadasFijas?: LlegadaFija[];
}

export interface Llegada {
  id: number;
  t: number;
  servicio: number;
  duracion: number;
}

export interface Trabajo {
  id: number;
  servicio: number;
  llegada: number;
  inicio: number;
  fin: number;
  elevador: number;
  usaBalanceadora: boolean;
}

export interface Perdido {
  id: number;
  t: number;
  servicio: number;
  servicioId: string;
  precio: number;
  hora: number;
}

export interface ResultadoReplica {
  semilla: number;
  atendidos: number;
  perdidos: Perdido[];
  alCierre: Llegada[];
  ingresoPerdido: number;
  ingresoPerdidoPorHora: number[];
  perdidosPorHora: number[];
  esperaMedia: number;
  ocupacionElevadores: number[];
  ocupacionBalanceadora: number;
  traza: Trabajo[];
  horizonte: number;
  finJornada: number;
  llegadas: Llegada[];
}

export interface Estad {
  media: number;
  ic: number;
  min: number;
  max: number;
}

export interface ResumenDia {
  dia: DiaTipo;
  replicas: ResultadoReplica[];
  atendidos: Estad;
  perdidos: Estad;
  ingresoPerdido: Estad;
  esperaMedia: Estad;
  perdidosPorHora: number[];
  ingresoPerdidoPorHora: number[];
  ocupacionElevadores: number[];
  ocupacionBalanceadora: number;
  alCierre: number;
}
