# Quicklube — simulador de elevadores

Simulador por eventos discretos para decidir cuántos elevadores/mecánicos habilitar cada hora del sábado, midiendo los autos que se van al ver la fila y la plata que se pierde. Funciona sin servidor: todo se guarda en este navegador (IndexedDB).

## Instalar y correr

```bash
npm install
npm run dev     # abre la app en modo desarrollo
npm test        # tests del motor (src/engine) con cobertura mínima del 80 %
```

## Datos de ejemplo

- **El catálogo es provisional**: servicios, precios, mezcla, duraciones, tasas de llegada por hora, horarios, K, cantidad de elevadores y reglas están en `src/config/catalogo.ts` (marcado «DATOS PROVISIONALES — se reemplazan con los del briefing»).
- Los **26.000 servicios históricos** (fechas, patentes, precios) son inventados por `src/data/semilla.ts` con una semilla fija. Si el navegador no deja guardar datos, se generan 2.000 en memoria.
- Los tests de `src/engine/__tests__/casosBriefing.test.ts` están vacíos a propósito hasta tener los casos reales.

## Reiniciar los datos de ejemplo

Entrá a **Panel** (pedile la clave al encargado) y tocá **Reiniciar datos de ejemplo**. Regenera los servicios históricos y vuelve el catálogo al de fábrica (queda registrado en el historial). También podés borrar el historial desde ahí.

## Cambiar la clave del Panel

Calculá el SHA-256 de `sal:clave` y reemplazá `CLAVE_PANEL_HASH` (y si querés `CLAVE_PANEL_SAL`) en `src/config/catalogo.ts`.

## Estructura

- `src/engine/` — motor en TypeScript puro (sin React ni DOM): RNG mulberry32, montículo, simulador, Erlang C, validaciones, historial por eventos.
- `src/worker/sim.worker.ts` — corre las réplicas en segundo plano.
- `src/lib/store.ts` — estado, IndexedDB, deshacer/rehacer y sincronización entre pestañas (BroadcastChannel).
- `src/routes/` — pantallas: Tablero, Simular, Gantt, Dotación, Catálogo, Historial, Servicios, Panel.
